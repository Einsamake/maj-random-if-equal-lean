# 当前文件夹整理审计（只读）

日期：2026-10-14。审计目标是降低入口混乱、隔离历史资料和删除可确定再生的缓存，不删除用户原稿、已验证证明、历史证据或锁定环境。本文未执行删除、移动或新增证明。

## 0. 主代理选定的执行结构（本审计尚未执行）

主代理已据审计选择以下结构，具体移动、删除、脚本修复及验收由主代理执行。本文后续“建议”是只读审计推导，不能代替执行清单。

- 根目录仅保留当前 `README`、`HANDOFF`、`STATUS`、阶段成果与复盘入口；原研究报告、附录、检索记录、复现说明、Word、研究清单移至 `reports/initial-research/`。
- 三个原生成脚本移至 `scripts/`，主代理修正ROOT、报告目录、预览输出目录后再验证；不是直接移动即可运行。
- 新交付包放 `deliverables/`。所有旧包移至 `archive/packages/`；16:33阶段包以 `_1633` 名保存，21:33重复包只保留一份。
- 清理前原HANDOFF、STATUS、FORMALIZATION_MAP、NEXT原文快照留存 `archive/docs/2026-10-14-before-cleanup/`；当前入口精简为准确现状。
- 散落FiniteTail日志移 `formal/audit/history/early-finite-tail/`，并修模块说明引用；ClockEventWord旧审计移 `formal/audit/history/clock-event-word/`。
- 删除4个字节码缓存与qa PNG，qa PDF移 `archive/qa/`；不动工具链、依赖缓存、正式Lean源码、mathlib原始证据。

以上均为收到的执行方案，本文不宣称这些操作已经完成。最终准确路径与哈希以主代理整理验收记录为准。

## 1. 范围与当前状态

已列出本地文件、读取打包／报告脚本、检查相关引用、核对精确重复。遍历跳过 `formal/.tools`、`formal/.lake`、`formal/analysis/.lake` 与任何 `.git`。本次扫描到非缓存文件391个，总计12,114,580字节；这是整理前只读扫描值，不代表随后整理完成后的数量。

`formal/audit/analysis-validation.json` 记录2026-10-14 16:32:59+08:00验证：60个分析模块、814个公开定理、61份项目Lean源码；核心记录125个公开定理、1个模型定义、8份项目源码。构建和公理审计通过。当前结果是辅助连接阶段通过；完整主定理仍未完成。

目录中没有发现项目级 `AGENTS.md`。本次不将非git工作区视为可随意删除的临时目录。

## 2. 可以确定清理的缓存

以下四个文件均为Python源文件的字节码缓存，可按明确文件名删除，再移除对应空目录。合计69,345字节；源脚本和结果JSON必须保留。

| 文件 | 字节 |
|---|---:|
| `research/cellular/__pycache__/check_decomposition.cpython-312.pyc` | 10,994 |
| `research/numerical/__pycache__/search_moments.cpython-312.pyc` | 19,063 |
| `research/online/__pycache__/exact_covariance_audit.cpython-312.pyc` | 18,390 |
| `research/online/__pycache__/exact_heptagon.cpython-312.pyc` | 20,898 |

`formal/analysis/scratch/` 经实际枚举为空，可删除空目录。没有发现需要保留的未完成证明草稿藏在该目录。

## 3. 已核对的精确重复

以下两份ZIP内容逐字节相同，均为200,774字节，SHA256均为：

`43905ab0ad18d5e1acceebafef594863640687005903f819e78ba336e446e0c8`

- `Lean形式化材料_2026-10-13.zip`
- `Lean形式化材料_2026-10-13_2133.zip`

整理时只需保存一份。推荐保留带阶段时间的版本，并在归档索引记录旧名称对应同一哈希；删除另一个副本前处理其 `.sha256` 和当前文档中的历史引用。`HANDOFF.md`、`STATUS.md`、旧阶段记录里有不带时间名称的历史叙述，不能让“最新包”文字继续误导读者。不要将不同时间的其他ZIP当作重复删除。

唯一另一组精确重复是 `formal/analysis/lean-toolchain` 与 `formal/audit/mathlib-source/lean-toolchain`。它们分属工程配置与历史源码证据，应各自保留。

## 4. 应归档而非删除的资料

| 资料 | 建议 | 理由／依赖 |
|---|---|---|
| 根目录旧Lean包：2026-10-13的16:06、20:44、21:33及2026-10-14的02:19版本 | 移至统一历史包目录，保留唯一副本和哈希索引 | 可复核阶段差异；不是可再生缓存。当前阶段包另存明确日期／阶段版本，避免日期相同的覆盖 |
| `qa/page-1.png` 至 `page-7.png` 与 `qa/report.pdf` | 可移至历史排版预览目录；若选择删除则明确记录是可再生预览 | 共3,004,674字节，`REPRODUCE.md`／`STATUS.md`记录其排版检查用途。不是数学证据；保存一份更稳妥 |
| `formal/analysis/_ClockEventWordAudit.lean`、`_ClockEventWordAudit.txt` | 移入 `formal/audit/history/` 下明确阶段子目录 | 2,495+5,849字节，早期事件字的实际公理审计源和输出，不是临时未验证证明 |
| `formal/analysis/MathResearchAnalysis/FiniteTail.compile.log`、`.build.log`、`.axioms.log` | 移入早期FiniteTail审计历史子目录并修同目录 `FiniteTail.md` 第9行引用 | 共3,087字节，各有 `EXIT_CODE=0`。统一审计已经覆盖，但原文明确引用，直接删除会丢历史凭证 |
| `formal/audit/SchedulingAxiomCheck.lean` 与 `scheduling-validation.txt` | 可一起收入早期核心审计历史，先核对引用 | 前者含当时完整Scheduling源码和21个公理打印；不是单纯自动生成的导入文件。当前核心统一审计已覆盖 |
| `formal/PROGRESS_*.md`、根目录HANDOFF中的历史段落 | 保留并区分当前状态与历史；若移动需同步打包脚本 | 详细阶段边界有价值；优先新增短入口和时间线，不为“整洁”改写历史事实 |

`qa`预览图片与现Word版本页数可能不是同一次完整输出；不要将保存预览本身当作当前Word重新验收。此轮用户未要求重新生成Word。

## 5. 必须保留的内容

- `REPORT.md`、`数学开放问题证明尝试记录.docx`、`TECHNICAL_APPENDIX.md`、`SEARCH_LOG.md`、`REPRODUCE.md`：原研究成果与复现说明。即便当前继续的是CA，回归研究也须完整保留。
- `research/` 下原脚本、JSON、TXT、Markdown以及作者／论文检索记录：脚本结果是历史实际运行证据，不能以可再生为由清空。
- `formal/MathResearch/`、`formal/analysis/MathResearchAnalysis/`、两个聚合入口、lake配置和锁定文件：已验证证明工程的固定路径。
- `formal/audit/*validation.json`、构建／公理输出、独立审查、生成公理检查源、`formal/audit/history/`：证明范围和可信边界的证据。
- `formal/audit/mathlib-commit.json`、`mathlib-master-tree.json`、`mathlib-source/`及LICENSE：原始库接口检索证据。目录树JSON虽然约3.51MB，也不应因体积较大直接删除。
- `quota-resume/.../checkpoint.md`、`schedule-verification.json`：当前暂停状态和两次一次性调度处理记录。不能因两个提醒已停用而清空交接。
- `.tools`与`.lake`：环境重建昂贵，且两个Lean版本缓存不得混用。本次用户要求文件整理，不构成重置依赖许可。

## 6. 移动会破坏哪些依赖

### 根目录脚本

`build_report.py` 将自身所在目录视为ROOT，读取 `ROOT/REPORT.md`，输出Word和技术附录，并从 `research/...` 明列12份稿件／审查拼接附录。直接把它移到 `scripts/` 会使所有输入输出落错位置。

`package_materials.py` 同样以自身所在目录为ROOT，明列9个根目录报告／脚本文件，递归打包 `research/` 中md/py/json/txt，输出根目录MANIFEST与研究ZIP。若移动脚本、报告或研究子目录，必须同时修ROOT与路径清单。新整理报告放入 `research/followup/` 后会自动进入下次研究包；打包时机应在整理与复盘完成之后，避免把旧清单当成最新。

`export_word.ps1` 使用 `$PSScriptRoot` 读取根目录Word并输出 `qa/report.pdf`。移动脚本会改变文档和预览目标；仅移走既有qa预览不会损害未来导出，因为脚本会重建qa目录。

### Lean打包及验证

`formal/scripts/package_lean.py` 以脚本上两级目录为项目ROOT，明列当前交接、阶段报告、正式源码、分析公理源、历史审计四个时间子目录和独立审查。移动历史审计／阶段记录后不更新列表，将直接触发 `assert all(path.is_file())` 失败。其输出包文件名也需在改为交付目录时一起修改，并保证 `.zip.sha256` 的记录文件名准确。

`validate_core.py`、`validate_analysis.py`、`audit_poisson_interfaces.py` 均以 `formal/scripts` 的相对位置查正式工程和安装依赖。保留该脚本目录、两个正式源码目录和锁定配置原位。当前validator只扫描正式模块目录和聚合入口，不因把根部旧临时审计移动至audit就改变814/125计数。

生成 `LEAN_MANIFEST.json`、`package-validation.json` 只说明对应一次打包的内容。整理报告／交接或打包脚本变化后，应重新打包并校验；不能继续称旧ZIP含最新说明。只移动文档和历史证据而不改正式Lean源码时，先核对69份源码哈希保持不变，无需为整理反复重建昂贵依赖。

### 研究脚本

多数脚本使用 `Path(__file__).with_name(...)` 输出同目录JSON；`research/followup/exact_route_barrier.py` 与 `exact_triangle_identity.py` 还从 `parents[1]/online` 导入精确算术。因此保留 `research` 现有内部相对布局，采用外层索引进行主题归类，不宜机械地把CA与回归所有文件拆成新目录。

## 7. 最小风险整理顺序

1. 建立当前成果入口、整理清单与历史包索引；保留正式证明和research内部布局。按第0节迁移根目录报告时，统一修正生成脚本输入输出。
2. 仅删除四个明确 `.pyc` 和空scratch；历史包／预览／旧散落审计移入有日期的归档目录，逐文件核对哈希。
3. 保留一份精确重复的21:33包并记录两个旧名映射；更新当前入口中的有效链接。
4. 修打包脚本的显式路径，核对所有必需输入存在、源码仍与审计哈希匹配，再生成交付包和清单。
5. 完成数学思路复盘，明确PW、CMST和两向恢复概率比较的缺口，之后才按用户新授权开始下一证明阶段。

本审计的建议不等于实际执行记录；整理执行者应另记准确删除／移动路径、校验结果及剩余问题。
