"""Package project proofs and audit evidence, without tools or dependency caches."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[2]
FORMAL = ROOT / 'formal'
checked_sources = 0
for name, base in [('core-validation.json', FORMAL),
                   ('analysis-validation.json', FORMAL / 'analysis')]:
    validation = json.loads((FORMAL / 'audit' / name).read_text(encoding='utf8'))
    assert validation['build_exit'] == validation['axiom_audit_exit'] == 0
    for source_name, expected in validation['source_sha256'].items():
        assert hashlib.sha256((base / source_name).read_bytes()).hexdigest() == expected
        checked_sources += 1
paths = [ROOT / name for name in ['HANDOFF.md', 'STATUS.md',
    '阶段性成果_2026-10-14.md',
    'research/followup/ca_clean_proof.md',
    'research/followup/public_resolution_check_2026-10-14.md']]
for directory in ['MathResearch', 'analysis/MathResearchAnalysis', 'scripts']:
    paths += sorted(path for path in (FORMAL / directory).iterdir()
                    if path.is_file() and path.suffix in {'.lean', '.md', '.py'})
for name in ['MathResearch.lean', 'lakefile.toml', 'lean-toolchain',
    'analysis/MathResearchAnalysis.lean', 'analysis/lakefile.toml',
    'analysis/lean-toolchain', 'analysis/lake-manifest.json', 'analysis/AnalysisAxioms.lean',
    'analysis/TaskPathsAudit.lean',
    'FORMALIZATION_MAP.md', 'LEAN_README.md', 'PROGRESS_2026-10-13.md',
    'PROGRESS_2026-10-13_CLOCKS.md', 'PROGRESS_2026-10-13_READINESS.md',
    'PROGRESS_2026-10-14_STOPPED_CLOCKS.md',
    'PROGRESS_2026-10-14_WORDS.md',
    'NEXT_STOPPED_WAIT.md']:
    paths.append(FORMAL / name)
for name in ['core-validation.json', 'core-build.log', 'core-axioms.log', 'CoreAxioms.lean',
    'analysis-validation.json', 'analysis-build.log', 'analysis-axioms.log',
    'poisson-interface-audit.json', 'task-path-semantic-review.md', 'concrete-clock-review.md',
    'readiness-clock-review.md', 'stopped-clock-review.md']:
    paths.append(FORMAL / 'audit' / name)
paths += sorted((FORMAL / 'audit' / 'history' / '2026-10-13-1606').iterdir())
paths += sorted((FORMAL / 'audit' / 'history' / '2026-10-13-2044').iterdir())
paths += sorted((FORMAL / 'audit' / 'history' / '2026-10-13-2133').iterdir())
paths += sorted((FORMAL / 'audit' / 'history' / '2026-10-14-0219').iterdir())
stage_audits = set()
for pattern in ['clock-rank-tail-*', 'rank-slot-embedding-*', 'clock-marks-*',
                'clock-execution-law-*', 'clock-selected-marks-*',
                'finite-word-kernel-*', 'marked-event-trace-*', 'square-gibbs-*',
                'ClockRankTailAxioms.lean', 'RankSlotEmbeddingAxioms.lean',
                'ClockMarksIndependentAxioms.lean', 'ClockExecutionLawAxioms.lean',
                'ClockSelectedMarksAxioms.lean', 'FiniteWordKernelAxioms.lean',
                'MarkedEventTraceAxioms.lean', 'SquareGibbsAxioms.lean',
                'SquareGibbsLawAxioms.lean']:
    stage_audits.update(path for path in (FORMAL / 'audit').glob(pattern) if path.is_file())
paths += sorted(stage_audits - set(paths))
assert len(paths) == len(set(paths))
assert all(path.is_file() for path in paths)
manifest = {path.relative_to(ROOT).as_posix(): {
    'bytes': path.stat().st_size,
    'sha256': hashlib.sha256(path.read_bytes()).hexdigest()
} for path in paths}
manifest_path = FORMAL / 'LEAN_MANIFEST.json'
manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf8')
paths.append(manifest_path)
output = ROOT / 'Lean形式化材料_2026-10-14.zip'
with zipfile.ZipFile(output, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
    for path in paths:
        name = path.relative_to(ROOT).as_posix()
        assert not ({'.tools', '.lake', '.git'} & set(Path(name).parts))
        archive.write(path, name)
with zipfile.ZipFile(output) as archive:
    assert archive.testzip() is None
    assert len(archive.namelist()) == len(paths)
    for name, record in manifest.items():
        content = archive.read(name)
        assert len(content) == record['bytes']
        assert hashlib.sha256(content).hexdigest() == record['sha256']
record = {'files': len(paths), 'zip_bytes': output.stat().st_size,
    'sha256': hashlib.sha256(output.read_bytes()).hexdigest(),
    'validated_sources_matched': checked_sources, 'checks_passed': True}
(FORMAL / 'audit' / 'package-validation.json').write_text(
    json.dumps(record, ensure_ascii=False, indent=2), encoding='utf8')
output.with_suffix('.zip.sha256').write_text(
    record['sha256'] + '  ' + output.name + '\n', encoding='utf8')
print(json.dumps(record, ensure_ascii=False))
