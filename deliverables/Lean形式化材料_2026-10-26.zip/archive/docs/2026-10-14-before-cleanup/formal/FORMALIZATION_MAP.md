# CA 候选证明的 Lean 对应表与可信边界

> **2026-10-14 16:33 阶段统一验收并按用户要求暂停：** 分析60模块、814公开定理，核心125未改；总构建和全部公理审计通过。事件字、实际rank概率、clock-only公平标记及selected-task律、rank槽与删选执行等价、真实同步／交替拆分、有限word零温实际执行积分、Gibbs有限归一化质量和详细平衡／平稳性已完成。详见 [本阶段技术记录](PROGRESS_2026-10-14_WORDS.md)。下方关于这些连接的旧待办均已过时；PW删更新、CMST、两向恢复比较及最终主定理尚未完成。

> **2026-10-14 02:19 最新统一验收：** 分析39模块、501公开定理，核心125未改，总构建与全部公理审计通过。任意非负AE有限实际停时的单站下一严格响铃law／共同停时历史独立性已证明；实际多层尾界不再要求概率结论输入。全部chronological事件几乎处处无同刻，真实贪心链矩、非严格下尾和给定链支配已证明。详见 [本轮记录](PROGRESS_2026-10-14_STOPPED_CLOCKS.md)。下方停时残余law／独立性和多层尾界的旧待办已过时；完整未来向量强Markov、事件字／标记联结、rank概率连接、PW／零温、CMST和完整主定理仍未完成。

> **2026-10-13 21:33 最新验收：** 分析工程为26模块、345定理。已实际构造多层扩展停时、共同几乎处处有限性、冲突保序／事件身份、实数路径及物理事件连接、真实固定路径过滤族；第一正层law与物理尾界已无条件推出。确定阈值无记忆性、真实扩展计数部分性质以及真正独立信息下的随机阈值生存因子化已证。详细范围见 [多层实际模型记录](PROGRESS_2026-10-13_READINESS.md)。下方“多层 readiness 尚未构造”的状态已过时；停时后残余law／历史独立性、随机更新字／标记联结、PW／零温、CMST和完整主定理仍未完成。多层物理尾界仍有law／独立性输入，不能由确定阈值或独立坐标阈值因子化自动解除。

> **2026-10-13 20:44 最新验收：** 分析工程为15模块、188定理。实际有限四邻格到路径递推的结构连接、真实独立指数序列、共同到达历史、严格下一铃的停时／几乎处处有限性及有限站点事件集合有限已完成。精确范围见 [本轮模型记录](PROGRESS_2026-10-13_CLOCKS.md)。下面关于“具体方形尚未实例化”“没有实际随机时钟空间”的待办已是历史状态；多层扩展 readiness、Poisson 计数／强 Markov、PW／零温、CMST 和完整主定理仍未完成。

> **2026-10-13 16:06 最新验收：** 分析工程已扩展为九个模块、86 个公开定理，总构建和全部公理审计均退出 0。新增 `NonnegativeMoment` 已解除前缀可积输入；`ExtendedBlockTail` 从允许无穷的时间推出期望有限与无穷事件测度为零；`StoppingPath`、`PathTail`、`TaskPaths`、`TaskPathTail` 已证明泛型实数任务路径展开、实际枚举计数和单步条件矩下的任务最大尾界。逐模块表和精确剩余假设见 [本轮记录](PROGRESS_2026-10-13.md)。以下旧对应表继续保留为历史，不能作为当前完成状态。完整 Poisson、PW、零温、CMST 与 CA 主定理仍未形式化。

> **2026-10-13 下午更新：以下旧对应表保留为早期记录，不能直接当作当前状态。** 最新完整覆盖表和下一步见项目根目录 `HANDOFF.md`。实际已经完成 `Grid` 的整数格点实例、`Trace` 的冲突保序重排定理以及 `Readiness`、`EventEmbedding` 模块。新增独立 mathlib 分析工程的 `ConditionalMoment`、`FiniteTail`、`BlockTail`，全部 27 个定理已完成统一构建和公理审计；记录在 `audit/analysis-validation.json`。因此旧表中“未实例化格点”“未完成重排组合定理”“没有概率分析模块”等描述已经过时。完整 Poisson 模型、PW、CMST 及完整 Θ(n²) 主定理仍未形式化。下文的源码检索范围与深层依赖边界仍可参考。

核对对象：`research/followup/ca_clean_proof.md`，版本 2026-10-13。实际项目使用 Lean 4.35.0，编译器提交 `eb6cafb7290e8bd5f2937522d8d804f58f02bafc`。本文件把**本地已形式化事实**、**通用库可提供的基础**和**尚未形式化的概率／外部定理**分开记录。

本项目当前没有证明候选主定理 `τ(n) = Θ(n²)`。确定性辅助模块通过检查，不等于八个引理及概率模型已经全部检查。特别是 CMST 方岛定理、Peres–Winkler 删更新定理、Poisson 向量在停时后的强 Markov 性，当前均没有被本项目 Lean 内核证明。

## 1. 实际模块与数学含义

所有本地数学模块只导入 Lean 标准库 `Std`；没有将候选主定理、其概率不等式或外部主定理写成自定义公理。本项目的证明范围以 Lean 声明的精确命题为准。

| 模块 | 精确对应 | 不能据此声称的内容 |
|---|---|---|
| `MathResearch/Majority.lean` | 实际四个布尔邻格的多数／平局规则；固定平局标记下的全零保持、至多一个 1 时输出零、共同标记单调性。 | 公平随机标记的概率空间、无限格点方形封闭性、随机初态分布支配。 |
| `MathResearch/Dynamics.lean` | 在 `BipartiteSystem` 中定义同步与交替轨迹，证明拆链公式、零态保持、吸收事件和有限首达时间的比较。`opposite_local` 表达更新只依赖异色坐标，`zero_update` 表达全零固定。 | 尚未把该抽象结构实例化为 `ℤ²` 四邻格、固定外部零边界和独立公平标记；有限首达时间比较本身不证明有限首达时间存在。 |
| `MathResearch/Trace.lean` | 有限更新字执行、独立相邻交换保持终态、由交换生成的等价字保持终态；从读取／写入不相交推导单格更新交换。 | 未完成“所有冲突对次序相同 ⇒ 两字由独立相邻交换连接”的完整有限字组合定理，也未证明随机删选后的分布定理。 |
| `MathResearch/Scheduling.lean` | 依据有限字的前驱冲突实际递归计算 rank，证明先前冲突事件的 rank／槽严格较早；rank 到 `2ρ−1/2ρ` 颜色槽的算术、非空自然数 max-plus 步的最大值与实现见证、有限二进制等比和。 | 没有将该有限字算法实例化为实际 Poisson 事件字，也没有证明连续时间任务路径递推或任一概率／期望尾界。 |

结构性假设可以合理地出现在泛型引理中。例如读取集合不含另一格，确实足以推导两单格更新交换；这与把所需的删更新随机偏序或 `Θ(n²)` 主结论作为前提有本质区别。实际二维随机 CA 仍需要逐项实例化这些结构接口。

## 2. 逐引理对应

| 候选稿步骤 | 本地 Lean 已覆盖内容 | 尚需证明／连接的内容 |
|---|---|---|
| 引理 1：方形封闭及最大初态支配 | `Majority.at_most_one`、`Majority.monotone_common_mark`、`Majority.zero_fixed` 核对真正的四邻格局部规则。 | 整数格点、轴平行方形外点至多一个内部邻格、无限轨迹归纳；独立随机标记及分布层面的支配。 |
| 引理 2：同步拆成两条交替链 | `BipartiteSystem.splitting`、`active_value`、`inactive_value`；`synchronous_zero_implies_alternating_next_zero`、`both_alternating_zero_implies_synchronous_zero`；`absorption_times`、`firstZero_bracket`、`finite_absorption_comparison`。 | 实际格点实例；每槽批次与逐格字的等价；随机联结及标记分布。首达比较须同时保留其有限吸收前提，不能读作已证明几乎必然吸收。 |
| 引理 3：保留冲突次序的字重排 | `Trace.cellUpdates_commute_of_read_write_disjoint`、`cellUpdates_commute_of_nonadjacent`，以及 `execute_eq_of_swapEquivalent`、`swapEquivalent_move_to_front`。 | 带唯一事件身份的两个有限字，从相同事件集合和冲突对顺序相同构造 `SwapEquivalent`；处理可能重复的格位置及不同标记。 |
| 引理 4：零温及 clock-only 随机删更新 | 当前没有概率形式化。 | 有限温度 Ising 测度、热浴核、PW 随机偏序定理、有限矩阵乘积的零温极限、条件于时钟后的标记独立性和积分。 |
| 引理 5：rank 嵌入及因果深度 | `Scheduling.annotate` 依据有限事件字实际计算 rank；`annotate_preserves_events`、`annotated_rank_positive`、`earlier_conflict_rank_lt`、`earlier_conflict_slot_lt` 核对事件不丢失、rank 正性及先前冲突的严格保序；`slot_within_depth`、`slot_injective_positive` 核对颜色槽算术。 | 完整 Poisson 字有限且无同刻事件、rank 图的链见证、字重排连接；`N5^(q−1)` 空间计数、重复格的阶乘矩测度、时序单纯形积分、`q! ≥ (q/e)^q`。式 (7) 尚未形式化。 |
| 引理 6：readiness 和字等价 | `Trace` 的确定性交换事实可复用。 | 建立 clocks-only 过滤族及通常增广，所有 `R`、`C` 是有限停时，严格下一响铃、不同任务不复用事件、全部冲突任务的保序、实际删选字和交替字的分布一致。 |
| 引理 7：路径指数矩与完成时间 | `Scheduling.completion_path_max`、`completion_attained`、`predecessor_completion_le` 核对**自然数值、单层、非空前驱列表**的 max-plus 恒等式及见证。 | 连续时间 `ℝ` 值及多层合法路径展开、无孤立格导致末层支配；停时后指数等待条件矩、前序可测性、指数乘积可积性、条件期望递推、路径计数和并集界。式 (11)–(12) 尚未形式化。 |
| 引理 8：两向概率比较 | 其确定性接口分别对应 Dynamics／Trace／Scheduling 的部分结论。 | 配置偏序、有限字核、随机删选可测性、成功／失败事件分解，完成 (15) 和 (16)。当前没有 Lean 版概率比较定理。 |
| 第 5 节：二次上界 | `Scheduling.dyadicSum_add_one` 证明有限自然数等比和 `Σ_{j<n} 2^j + 1 = 2^n`。 | 该有限代数事实**不是**离散尾和公式，也不证明 `E[τ] ≤ 2b`。仍需 CMST 上尾、rank 失败概率、块 Markov／支配重启、无限尾和及积分、较大奇数方形和常数选择。 |
| 第 6 节：二次下界 | 有限吸收比较可用于确定性联结后的最后一步。 | CMST 下尾、完成时间失败概率、实心奇偶岛单调比较、光锥小尺寸下界、取整／对数误差、统一正下界常数及期望下界。 |

## 3. mathlib 实际源码核验

本次没有把搜索引擎的无结果当成库中不存在定理的证明。2026-10-13 从 [mathlib 官方仓库](https://github.com/leanprover-community/mathlib4) 获取了完整目录树，并固定到提交 [`54c01c3314d33d15d77893cbe4e0472ff26bb34d`](https://github.com/leanprover-community/mathlib4/tree/54c01c3314d33d15d77893cbe4e0472ff26bb34d)。本地保存：

- `audit/mathlib-master-tree.json`：GitHub 返回 `truncated = false` 的完整目录树及提交 SHA。
- `audit/mathlib-commit.json`：对应提交元数据。
- `audit/mathlib-source/Mathlib/Probability/`：该提交下全部 141 个概率论 `.lean` 文件。
- `audit/mathlib-source/Mathlib/MeasureTheory/`：额外核对的条件期望基础、实数条件期望和 Markov 不等式源文件。
- `audit/mathlib-source/LICENSE`：第三方源码许可证。

这些是审计资料，**没有作为本项目依赖编译**。本项目 `lake` 配置当前只使用 Std；因此“mathlib 中确认有某个基础”不表示本项目已经使用它证明概率结论。源码快照使检索结论可复查，但未核验全仓库所有文件的内容，也未穷尽其他 Lean 项目。

已确认的可复用基础如下。

| 所需基础 | 官方声明／源码 | 对本证明的真实作用 |
|---|---|---|
| Poisson 单次分布 | `ProbabilityTheory.poissonMeasure`、`IndepFun.hasLaw_add_poissonMeasure`，见 [Poisson/Basic.lean](https://github.com/leanprover-community/mathlib4/blob/54c01c3314d33d15d77893cbe4e0472ff26bb34d/Mathlib/Probability/Distributions/Poisson/Basic.lean)。 | 可用于计数分布与独立计数求和；不是 Poisson 计数过程、停止后独立增量或阶乘矩测度定理。 |
| 指数分布 | `ProbabilityTheory.expMeasure`、`isProbabilityMeasure_expMeasure`、`cdf_expMeasure_eq`，见 [Exponential.lean](https://github.com/leanprover-community/mathlib4/blob/54c01c3314d33d15d77893cbe4e0472ff26bb34d/Mathlib/Probability/Distributions/Exponential.lean)。 | 提供指数测度与 CDF；不能自动说明共享 Poisson 时钟所选的停时等待具有该条件分布。 |
| 停时最大值及停时 σ 代数包含 | `MeasureTheory.IsStoppingTime.max`、`IsStoppingTime.measurableSpace_mono`，见 [Stopping.lean](https://github.com/leanprover-community/mathlib4/blob/54c01c3314d33d15d77893cbe4e0472ff26bb34d/Mathlib/Probability/Process/Stopping.lean)。 | 支持有限最大值停时及 `F_σ ⊆ F_τ` 部分；下一严格响铃、有限性和强 Markov 仍需模型专用证明。 |
| 条件期望与塔式性质 | `MeasureTheory.integral_condExp`、`condExp_condExp_of_le`，见 [ConditionalExpectation/Basic.lean](https://github.com/leanprover-community/mathlib4/blob/54c01c3314d33d15d77893cbe4e0472ff26bb34d/Mathlib/MeasureTheory/Function/ConditionalExpectation/Basic.lean)；另有 `Filtration.condExp_condExp`。 | 提供递推工具；必须先补充可测性、可积性和停时等待的条件矩恒等式。 |
| Markov 不等式 | `MeasureTheory.mul_meas_ge_le_lintegral`，见 [Lebesgue/Markov.lean](https://github.com/leanprover-community/mathlib4/blob/54c01c3314d33d15d77893cbe4e0472ff26bb34d/Mathlib/MeasureTheory/Integral/Lebesgue/Markov.lean)。 | 可用于从已证明的非负指数矩推出尾概率；不能替代指数矩本身。 |

对全部 141 个概率源码执行了 `PoissonProcess / poisson process / StrongMarkov / strong Markov / censoring / Peres / Winkler / Ising / Caputo / Toninelli / Simenhaus / factorial moment` 的名称与关键词检索，并检查完整目录树中的相关路径。此次核验范围内没有检出可直接提供以下三项的声明：

1. **有限独立 Poisson 向量在共同时钟停时后的强 Markov 性**，包含本文所需 `E[exp(θD) | F_R] = (1−θ)^(-1)` 接口。
2. **Peres–Winkler 删更新定理及它的本文零温／clock-only 极限接口**。
3. **CMST 二维实心方岛在固定同色边界下的 `Θ(ℓ²)` 高概率首达时间界**。

这是一项有明确范围的“未检出可直接调用声明”结论。它不构成对全生态或所有其他名字下等价定理的不存在证明。源码中 Markov kernel、Markov inequality、martingale optional sampling 和 Poisson distribution 等已有条目，均不能据名字替代上述强 Markov 或 Ising 专用结果。

## 4. 完成完整主定理所需的接口顺序

1. 实例化整数格点四邻格与 `BipartiteSystem`，固定独立公平标记，补齐方形封闭性和 finite-volume 联结。
2. 完成有限字冲突保序的重排组合定理；把实际 rank 嵌入和 readiness 事件字连接到该定理。
3. 建立配置分布与热浴核，形式化有限温度 PW，再证明零温和 clock-only 条件化接口。
4. 建立有限独立 Poisson 向量、通常过滤族、下一严格响铃停时、强 Markov 和阶乘矩测度。
5. 完成式 (7)、(11)、(12)，再证明两向删更新比较 (15)、(16)。
6. 将 CMST 的**完整准确命题**接入；若仅在定理参数中假设 CMST，最终必须标为“以未形式化 CMST 为前提的条件性推论”。若把 PW 或强 Markov 也仅作假设，必须同时列明；不能称为无条件主定理的完整形式化。
7. 证明块重启、尾和／期望、奇偶尺寸、取整／对数和有限小尺寸常数，才可给出 Lean 版主定理。

当前可准确报告的成果是：**候选证明中的部分确定性接口已被真实 Lean 证明并检查，概率论桥接和外部深定理仍未形式化。** 若要报告最终内核验收，还应结合总项目构建、`#print axioms` 及项目源文件中的占位检查；第三方审计源码应与本项目证明源文件分开统计。
