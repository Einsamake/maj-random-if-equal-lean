# 后续证明路线（停时等待及事件字阶段已完成）

**2026-10-14 16:33 更新：本阶段已验收并按用户要求暂停。** 停时等待、实际事件字／rank概率、随机标记联结、rank槽及任务删选执行到交替轨迹、有限word零温极限和有限Gibbs基础均已实现，见 `PROGRESS_2026-10-14_WORDS.md`。下次授权恢复时从真正有限温度PW删更新及零温传递接续；随后CMST方岛、两向恢复事件比较、实际重启、尺寸和常数。下文保留历史路线，不再表示当前待办。

**2026-10-14 更新：下方 reset、可数停时分片、网格逼近和任意非负AE有限停时残余 law／历史独立性路线已实际实现，统一构建与公理审计通过。** 当前接口在 `ClockStoppedResidual.lean`；无输入概率结论的多层尾界在 `ActualClockTail.lean`。最新状态见 `PROGRESS_2026-10-14_STOPPED_CLOCKS.md`。

接下来直接连接有界时间真实有限事件字、rank 因果链见证和空间路径并集，再推进随机标记联结及PW／零温、CMST和最终比较；可复用本轮 `ClockNoTies` 和 `GreedyClockChain`。下文保留为历史证明设计，不再表示当前待办。

## 先处理确定时刻

固定站点 `v`、确定 `r≥0`、可测历史事件 `E∈clockHistory V r` 和确定 `t≥0`。目标是

\[
\mu\bigl(E\cap\{\operatorname{next}_v(r)>r+t\}\bigr)
=\operatorname{ofReal}(e^{-t})\,\mu(E).
\]

这里 `next` 是严格晚于 `r` 的实际扩展下一到达。不要先把随机 readiness 或随机当前 gap 索引替换成独立变量。

1. 固定候选间隔索引 `k`。令 `Pₖ` 为前 `k` 个 clipped gap 的和，`P₀=0`；它只依赖删去 `(v,k)` 后的其余坐标。候选区间为 `Cₖ(r)={Pₖ≤r<A(v,k)}`，非负阈值为 `sₖ(h)=max(0,r−Pₖ(h))`。
2. 定义 `reset(h)` 保留其余坐标，把 `(v,k)` 的 gap 设为 `sₖ(h)+1`。需新证明它可测。在候选区间上，当前与后续本格到达都晚于 `r`，前 `k` 个本格到达和其他站点到达不变。因此原样本与 `reset(restCoordinates ω)` 对所有历史生成事件 `{A(w,j)≤u}`、`u≤r` 的真假一致。
3. 将生成事件真假一致提升到全部历史可测事件。可直接使用 `MeasurableSpace.forall_generateFrom_mem_iff_mem_iff`；备用为 `MeasurableSpace.generateFrom_induction`。两者在 `Mathlib/MeasureTheory/MeasurableSpace/Defs.lean` 的第 363、340 行。
4. 对 `E` 定义 Rest 事件 `Bₖ={h|Pₖ(h)≤r ∧ reset(h)∈E}`，通过 `clockHistory.le r` 和 reset 可测性证明它可测。需新证明 `E∩Cₖ(r)` 等于“rest 属于 `Bₖ` 且当前 gap 大于 `sₖ(rest)`”，以及再要求 `next_v(r)>r+t` 等于当前 gap 大于 `sₖ(rest)+t`。然后调用已验收的 `RandomThresholdSurvival.actual_gap_survival_factorization`。
5. 需证明候选区间两两不交且几乎处处覆盖。可使用 `chronologicalArrival_monotone`、`clock_future_arrival_ae`、`clock_locally_finite_ae` 和计数阈值接口，再按确定 `k` 求和。`MeasureTheory.measure_iUnion` 在 `Mathlib/MeasureTheory/Measure/NullMeasurable.lean` 第 241 行，要求两两不交和各项可测；第 250 行的 `measure_iUnion₀` 对应几乎处处不交／零可测情形。

上述每一步仍须实际编译证明。Rest 信息可能含其他坐标的未来，它并不是 `F_r`；用途是利用候选区间上的历史事件不变性，而不是声称整个历史独立于当前 gap。坏样本的无限计数不能用自然数默认值零隐藏。

## 再处理真正的停时

确定时刻历史因子化完成后，才考虑非负、几乎处处有限的实际扩展停时 `R`。可探索从上方的离散逼近 `R_m=2^{-m}⌈2^mR⌉`，但扩展无穷值与取整定义须准确处理。逼近停止性、可数取值、收敛和下一索引最终恒定都尚未证明。

本地可复用 `IsStoppingTime.measurableSpace_mono`（`Stopping.lean` 第 463 行）及 `IsStoppingTime.measurableSet_eq_of_countable_range`（第 120 行）。通过 `F_R≤F_{R_m}`，按离散逼近的可数取值分解历史事件。实际局部有限性和严格到达可用于下一到达索引稳定；当前 `clockHistory` 尚无右连续性证明，不能直接用需该条件的 `IsStoppingTime.iInf`。

`R≥0` 是必要条件：模型从时间零启动，负 readiness 的等待一般不具有同一 `Exp(1)` law。最终还需把残余尾恒等式升级为真实 law 与停时历史独立性，再解除 `ClockMaximum.actual_square_eight_tail` 的两个概率输入。完整强 Markov、后续随机比较和 CA 主定理均未由本路线证明。
