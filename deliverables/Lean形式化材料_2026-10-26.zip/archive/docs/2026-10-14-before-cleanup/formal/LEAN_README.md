# Lean 材料使用说明

**最新阶段：2026-10-14 16:33 统一验收。** 分析60模块、814公开定理，核心125公开定理及模型定义未改；无占位或自定义公理。实际事件字、rank概率、独立公平标记联结、具体排序／删选执行到交替轨迹、有限word零温极限和有限Gibbs详细平衡／平稳性已经完成，完整Θ(n²)主定理尚缺PW删更新、CMST和最终比较。按用户要求已阶段暂停。先读根目录 `阶段性成果_2026-10-14.md` 和本目录 `PROGRESS_2026-10-14_WORDS.md`；下面02:19及更早说明作为历史背景。

本目录保存二维多数细胞自动机候选证明的已检查部分。完整 `Θ(n²)` 主定理尚未形式化；停时等待、时钟尾界以及本阶段事件字／rank／标记和执行连接已经证明，恢复时间期望仍须PW、CMST及实际概率比较。最新覆盖范围见 `PROGRESS_2026-10-14_WORDS.md`，交接见项目根目录 `HANDOFF.md`。分析工程目前60模块、814公开定理，核心125公开定理和模型定义未改。最新包为项目根目录 `Lean形式化材料_2026-10-14.zip`。

## 先看哪些文件

1. `PROGRESS_2026-10-14_WORDS.md`：最新技术说明、实际连接、剩余缺口及阶段验收；`PROGRESS_2026-10-14_STOPPED_CLOCKS.md`为上一阶段。
2. `analysis/MathResearchAnalysis.lean`：分析工程总入口。
3. `audit/analysis-validation.json`：真实构建、公理审计、逐模块定理数和源文件 SHA256。
4. `audit/analysis-build.log`、`audit/analysis-axioms.log`：完整验收日志。
5. `LEAN_MANIFEST.json`：材料包内逐文件大小和 SHA256。
6. `NEXT_STOPPED_WAIT.md`：已实现的停时残余等待路线历史及当前接续方向。

`MathResearch/` 是确定性核心，`analysis/MathResearchAnalysis/` 是使用 mathlib 的分析部分。路径和停止时间都各有明确接口，不能把文件名中的 “moment” 或 “stopping” 理解为已经构造实际 Poisson 过程。

## 当前 Windows 环境直接复现

工作目录是 `C:\Users\Lenovo\Desktop\Project\Math`。依赖已安装；在这个目录续做不要重新下载，也不要重置 `.lake/packages`。

在 PowerShell 中执行：

```powershell
Set-Location -LiteralPath 'C:\Users\Lenovo\Desktop\Project\Math'
& 'C:\Users\Lenovo\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe' -X utf8 formal\scripts\validate_core.py
& 'C:\Users\Lenovo\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe' -X utf8 formal\scripts\validate_analysis.py
```

脚本会分别选择正确的工具链、构建总入口、生成逐定理 `#print axioms`，检查项目源码中的占位及绕过内核构造，最后写入 `formal/audit` 的日志和哈希。分析脚本还实际核对编译器版本和 mathlib 的 HEAD 提交，并检查每个提取出的定理都有审计输出。退出码为零才表示该次验收成功；旧日志不能替代修改后的重新验收。

只检查一个分析模块时，先把分析编译器目录加入当前进程 PATH，再在分析目录运行：

```powershell
Set-Location -LiteralPath 'C:\Users\Lenovo\Desktop\Project\Math\formal\analysis'
$env:PATH = (Resolve-Path '..\.tools\lean-4.35.0-rc4-windows\bin').Path + ';' + $env:PATH
& '..\.tools\lean-4.35.0-rc4-windows\bin\lake.exe' build MathResearchAnalysis.NonnegativeMoment
```

将末尾模块名改为 `ExtendedBlockTail`、`TaskPaths` 或其他模块即可。不要用核心的最终版编译器加载分析工程的 rc4 缓存。

## 版本与警告

| 工程 | 工具链 | 依赖 |
|---|---|---|
| 核心 `formal/` | Lean 4.35.0 | Lean 标准库 |
| 分析 `formal/analysis/` | Lean 4.35.0-rc4 | mathlib `54c01c3314d33d15d77893cbe4e0472ff26bb34d`；间接依赖见 `lake-manifest.json` |

旧分析模块已迁移到 `module` / `public import`；最终源文件诊断以构建日志为准。Lake 仍提示依赖仓库存在本地改动，本次保留原依赖，没有执行重置。不能把本次结果称为“所有环境均无警告”。

材料包排除了 `.tools`、`.lake`、`.git` 和第三方源码快照。它包含证明源文件、版本锁定文件、说明、验证脚本和验收证据，能够在已安装的本地环境直接复现。换机器时须先准备表中的两套工具链及锁定依赖，并保持相应目录布局；本次没有验证全新机器上的安装过程。用系统 Python 时，版本须支持脚本使用的标准库接口；本项目证明验收不需要额外 Python 数学库。

## 重新生成材料包

在项目根目录运行：

```powershell
& 'C:\Users\Lenovo\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe' -X utf8 formal\scripts\package_lean.py
```

脚本逐文件计算哈希，生成 `Lean形式化材料_2026-10-14.zip`，然后重新读取压缩内容，核对文件数、大小、SHA256 和压缩完整性。若修改了证明，先重新运行对应工程的验证，再打包；未改核心时保留匹配其源码的已有验收。

## 不能由本材料推出的结论

已经从真实独立指数到达空间构造全部多层扩展 readiness／completion，证明停时与共同几乎处处有限性，并连接实数路径、物理事件及冲突保序。任意非负AE有限真实停时的单站残余law／共同历史独立性、多层无概率输入尾界、全部事件无同刻及贪心链下尾已证明。尚未证明完整 Poisson 计数分布／同站独立增量及完整未来向量强Markov特征、实际有限更新字／随机标记联结、rank因果见证和空间并集、PW 删更新及零温接口、CMST 方岛定理；两向随机比较、块重启和最终常数也未完成。若未来以未形式化结果作定理参数，只能报告相应条件性推论。书面候选证明、Lean 辅助验证和外部数学／新颖性认证是不同的验收范围。
