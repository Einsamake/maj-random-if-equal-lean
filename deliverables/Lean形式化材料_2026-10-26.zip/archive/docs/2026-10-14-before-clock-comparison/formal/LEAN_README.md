# Lean 验证和材料使用

最新为分析 64 模块／842 公开辅助定理，核心 125 条定理及模型定义。具体见 [对应表](FORMALIZATION_MAP.md) 和 [PW 阶段技术记录](PROGRESS_2026-10-14_PW.md)。完整 `τ(n)=Θ(n²)` 未形式化；新增工作以修改后实际验收为准。

## 环境

| 工程 | 目录 | 编译器 | 依赖 |
|---|---|---|---|
| 核心 | `formal/` | Lean 4.35.0 | 标准库 |
| 分析 | `formal/analysis/` | Lean 4.35.0-rc4 | mathlib `54c01c3314d33d15d77893cbe4e0472ff26bb34d` |

编译器在 `formal/.tools/`，缓存分别在两个工程 `.lake/`。直接复用，不重置或混用。九项依赖本地改动提示已记录，不属于构建失败，不擅自清除。

## 本机复现

从根目录运行需要验收的工程：

```powershell
Set-Location -LiteralPath 'C:\Users\Lenovo\Desktop\Project\Math'
& 'C:\Users\Lenovo\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe' -X utf8 formal\scripts\validate_analysis.py
# 核心源有修改时再执行：
& 'C:\Users\Lenovo\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe' -X utf8 formal\scripts\validate_core.py
```

脚本构建总入口、扫描禁用构造、逐条运行全部公开定理 `#print axioms`，记录日志及哈希；分析另核对编译器和 mathlib 提交。退出 0 才表示本次通过，只使用与源码哈希匹配的记录。

单模块构建：

```powershell
Set-Location -LiteralPath 'C:\Users\Lenovo\Desktop\Project\Math\formal\analysis'
$env:PATH = (Resolve-Path '..\.tools\lean-4.35.0-rc4-windows\bin').Path + ';' + $env:PATH
& '..\.tools\lean-4.35.0-rc4-windows\bin\lake.exe' build MathResearchAnalysis.SquareGibbsLaw
```

## 原始证据

- `audit/analysis-validation.json`、`core-validation.json`：覆盖、计数、退出码及源哈希。
- `audit/analysis-build.log`、`analysis-axioms.log` 及核心日志：完整输出。
- `audit/*-review.md`：内部复核，不能替代外部数学认证。
- `audit/history/`：历史验收及早期单模块日志。
- `analysis/AnalysisAxioms.lean`：自动生成的逐定理审计入口。

## 打包

根目录运行 `formal/scripts/package_lean.py`，先核对正式源与成功验收哈希，再输出 `deliverables/Lean形式化材料_2026-10-14.zip` 和摘要，逐文件读回检查 CRC、大小与 SHA256。包排除编译器及依赖缓存。

`LEAN_MANIFEST.json` 为逐文件清单，`audit/package-validation.json` 为包验证。旧包在 `archive/packages/`，原 Word 在 `reports/initial-research/`。当前阶段按 [NEXT_PHASE](NEXT_PHASE.md) 验收，旧停时路线只保留跳转。
