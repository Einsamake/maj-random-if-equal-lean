# 当前 Lean 对应表与可信边界

最新验收：2026-10-14 20:56:32 +08。分析 64 模块／842 公开定理，核心 7 模块／125 公开定理及模型定义。**完整 CA `Θ(n²)` 未形式化。** 旧叠加表见 `archive/docs/2026-10-14-before-cleanup/formal/FORMALIZATION_MAP.md`。

| 数学内容 | 主要实际模块 | 状态与边界 |
|---|---|---|
| 四邻格、支持封闭及同步拆分 | 核心 `Grid`、`Dynamics`；分析 `SquareTasks`、`SquareSpin`、`SquareDynamics` | 规则及几何已接通；分析域边长 `n+2`，最终参数仍须连接 |
| 矩、路径及扩展块尾 | `NonnegativeMoment`、`TaskPaths`、`TaskPathTail`、`ExtendedBlockTail` | 通用工具已证，不能替代真实恢复重启和尾输入 |
| 实际指数时钟及历史 | `ExponentialClocks`、`ArrivalFiltration`、`ClockCounting`、`ClockNoTies` | 保留无穷坏样本；有限格局部有限及 AE 无同刻已证 |
| 真实停时残余 law | `ClockStoppedResidual` 及 reset／近似依赖 | 非负 AE 有限停时的单站等待 Exp(1) 及共同历史独立性已证；非全未来向量强 Markov |
| 多层任务及物理尾 | `ClockReadiness`、`ClockEventOrder`、`ActualClockTail` | 实际停时构造、AE 有限、身份不复用及无概率输入尾界已证 |
| 事件字及 rank 尾 | `ClockEventWord`、`FiniteRankWitness`、`SquareGreedyPaths`、`ClockRankTail`、`SchedulingFailure` | 计算 rank 经真实链及路径并集给尾界；尚非 CA 恢复尾 |
| 标记及执行 law | `FairMarks`、`ClockWordMarks`、`ClockExecutionLaw`、`ClockSelectedMarks` | clock-only 身份注入选择已实例化；不含任意读标记的自适应删选 |
| 重排及交替任务字 | `EventTrace`、`MarkedEventTrace`、`RankSlotEmbedding`、`ClockSelectedWord`、`SquareBatch` | 同事件标记的冲突保序重排及任务字交替执行已证；完整扫描 Sublist 仍缺 |
| 零温与真实执行积分 | `ZeroTemperature`、`FiniteWordKernel` | 固定有限字核极限及公平执行积分已证 |
| Gibbs 基础 | `SquareGibbs`、`SquareGibbsLaw` | 零边界能量、正归一化质量、核、详细平衡及平稳性已证 |
| 有限字 PW | `SquareAttractivity`、`SquarePWMeasure`、`SquarePWDrop`、`SquarePWCensoring` | 最大态任意有限字 Sublist 删更新、零温及实际执行积分已证；随机 clock 恢复比较仍缺 |
| CMST／FSS 方岛 | 尚无完整模块 | 深依赖未形式化，不能作为核心概率参数或自定义公理 |
| 两向恢复比较、重启、期望 | 尚未闭合 | 泛型块尾和候选稿不能替代真实模型连接 |

分阶段细节按 `PROGRESS_*.md` 日期阅读，当前执行只看 [NEXT_PHASE](NEXT_PHASE.md)。精确计数、哈希、公理和构建以 `audit/*-validation.json` 及对应日志为准。
