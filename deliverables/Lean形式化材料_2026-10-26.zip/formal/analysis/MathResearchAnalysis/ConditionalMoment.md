# 固定路径条件指数矩

> 2026-10-13 续做：本文保留旧接口说明。新增 `NonnegativeMoment.lean` 已从单步可积与真实条件矩证明前缀可积，新 wrapper 无需 `hprefixInt`。旧接口继续保留兼容调用；不再应把 `hprefixInt` 描述为整个工程尚未补上的缺口。最终统一验收见 `../../audit/analysis-validation.json` 和 `../../PROGRESS_2026-10-13.md`。本源码已迁移新版 module 格式，完整环境仍有依赖本地改动提示。

`ConditionalMoment.lean` 使用真正的 mathlib 条件期望与积分。分析子项目将 mathlib 固定在 commit `54c01c3314d33d15d77893cbe4e0472ff26bb34d`，配套 Lean 为 `4.35.0-rc4`。

## 证明的结论

在概率空间上，给定固定、预先选定的等待时间序列 `wait i` 和递增的子 σ 代数 `ℱ i`。若每一步满足

\[
\mathbb E[e^{\theta\,wait_i}\mid\mathcal F_i]=c
\quad\text{几乎处处},
\]

则长度为 `length` 的前缀满足

\[
\mathbb E\!\left[e^{\theta\sum_{i<length}wait_i}\right]
=c^{length}.
\]

这里的结论是实际的 Bochner 积分等式。输入假设没有把这个积分值或前缀积分值预先设为已知。

## 明确保留的假设

- `IsProbabilityMeasure μ`：总质量为一，用于空前缀的积分。
- `ℱ : Filtration Nat mΩ`：实际的递增子 σ 代数，并且每一层包含于环境 σ 代数。
- `hknown`：`wait i` 在 `ℱ (i + 1)` 下强可测；由此归纳证明之前全部等待时间之和、以及它的指数，在 `ℱ i` 下强可测。
- `hwaitInt`：每个单步指数因子在环境测度下可积。
- `hprefixInt`：每个有限前缀指数在环境测度下可积。这提供 pull-out 定理要求的乘积可积性；仅有单个因子可积不能自动代替它。
- `hconditional`：每个单步指数因子的真实条件期望几乎处处等于常数。这是条件分布/MGF 的输入，并非整个序列独立性的输入。

`hprefixInt` 包含空前缀，可从概率测度推出这一项；保留统一写法方便调用。非空前缀的可积性仍是明确的应用义务。

## 证明链

`integral_mul_of_condExp_const` 调用 mathlib 的 `condExp_mul_of_stronglyMeasurable_left`，把对当前 σ 代数已知的前缀因子提出条件期望。随后调用 `integral_condExp`，把条件期望的积分还原为原乘积的积分。概率测度的有限性保证所需的受限测度 σ 有限性。

`pathExp_succ` 用实指数加法公式把新前缀分成旧前缀指数与当前等待时间指数。`prefixSum_stronglyMeasurable` 利用 `Filtration.mono` 逐层提升旧前缀的可测性；`pathExp_stronglyMeasurable` 再用实指数的连续性。

`fixed_path_exponential_moment` 在长度上归纳：空前缀的积分为一，每次 pull-out 和 total-expectation 步骤乘上常数 `c`。`fixed_path_rate_one_moment` 代入 `c = (1 - θ)⁻¹`，得到 rate-one 指数等待时间所需的表达式。

## 应用范围

rate-one 版本把 Poisson 等待时间的条件 MGF 作为显式假设，尚未构造 Poisson 过程或证明强 Markov 性。实际指数分布 MGF 的常用参数范围 `θ < 1` 必须在未来证明这个条件 MGF 时核查；当前定理是从给出的条件 MGF 和可积性出发的逻辑推论，因此没有额外使用这一范围。

路径在概率结果中是固定的。模块没有证明对样本路径自适应选择的逻辑路径、路径计数、并集界、尾界、CMST/PW 删失耦合、Ising 灭绝时间，或相关期望/渐近阶。它只补上固定路径的条件性概率推论，不能被称为这些完整定理的形式化。

源码关闭自动隐式变量，不使用 `sorry`、`admit` 或自定义公理。2026-10-13 已用本地 Lean `4.35.0-rc4` 和固定版本依赖实际编译本模块，退出码为零，模块本身没有错误或警告；Lake 启动时提示依赖 checkout 存在本地变化，该提示与模块证明诊断不同。

已逐一运行六个公开定理的 `#print axioms`，全部只依赖 `[propext, Classical.choice, Quot.sound]`，没有 `sorryAx` 或自定义公理。它们分别为 `integral_mul_of_condExp_const`、`pathExp_succ`、`prefixSum_stronglyMeasurable`、`pathExp_stronglyMeasurable`、`fixed_path_exponential_moment` 和 `fixed_path_rate_one_moment`。
