# 有限路径族的积分 Markov 与指数尾界

> 2026-10-13 续做：全模块 12 个定理已纳入最终统一审计。新增 `PathTail` 和 `TaskPathTail` 将本模块接到由真实条件矩派生的路径 MGF、实际多层路径枚举与计数；完整路径 MGF 不再是这套新接口的额外假设。实际时钟条件矩仍是模型输入。最终覆盖见 `../../PROGRESS_2026-10-13.md`。

本模块位于独立的 mathlib 分析工程，不修改只用 `Std` 的核心工程。源码使用实际积分和测度：`Measure Ω`、`IsProbabilityMeasure μ`、Bochner 积分、`Integrable` 和 `MeasurableSet`。

编译状态：已使用 Lean 4.35.0-rc4 和锁定的 mathlib 提交 `54c01c3314d33d15d77893cbe4e0472ff26bb34d` 实际编译通过，退出码 0；最终 `lake build MathResearchAnalysis.FiniteTail` 也成功（2611 jobs），本模块没有错误或警告。Lake 对本地依赖仓库的修改提示属于环境状态。源码采用新版 `module` / `public import` / `public section`，可以供其他分析模块直接导入。

早期日志已归档到 [`formal/audit/history/early-finite-tail`](../../audit/history/early-finite-tail/)，包括 `FiniteTail.compile.log`、`FiniteTail.build.log` 和 `FiniteTail.axioms.log`，每份日志都记有最终 `EXIT_CODE=0`。最后一份早期日志检查了 7 个关键定理；当前完整模块以 [`analysis-validation.json`](../../audit/analysis-validation.json) 为准。公理依赖全部为 Lean 标准三项，没有 `sorryAx` 或自定义公理。

## 明确的接口

`finiteExceeds paths value t` 表示有限 `Finset` 路径标签中至少一条路径的值大于 `t`。路径标签之间可以共享随机变量，模块没有假设不同路径独立。

一般非负随机变量的接口明确要求：

- 概率测度 `μ`。
- 每条变量可积。
- 每条变量几乎处处非负。
- 阈值 `c > 0`。
- 每条变量的实际积分不超过给定实数 `A`。

`nonnegative_single_tail` 直接调用 mathlib 的 `mul_meas_ge_le_integral_of_nonneg`，证明单变量严格阈值事件的概率不超过 `A / c`。`finite_nonnegative_tail` 使用 `measureReal_biUnion_finset_le` 和有限求和，证明并集概率不超过 `cardPaths * A / c`。

`finite_nonnegative_tail_with_measurability` 另外明确接收每条变量的 `Measurable` 证据，证明整个阈值事件为可测集，并同时给出上述概率界。

## 指数实例化

对路径值 `S_p`，令 `Y_p = exp(θ S_p)`。`finite_exponential_tail` 在 `θ > 0`、每条 `Y_p` 可积且 `∫ Y_p dμ ≤ A` 的假设下，将严格阈值事件改写为 `Y_p > exp(θ t)`，从已经证明的有限 Markov 界推出：

\[
\mathbb P\bigl(\exists p\in\mathcal P:S_p>t\bigr)
\le |\mathcal P|\,A\,e^{-\theta t}.
\]

这里没有将最后这个概率不等式作为假设。传入的 MGF 上界是每条路径的**积分矩上界**，可由另一个条件矩模块提供。

## 实际有限最大值和路径和

`finiteMaximum` 使用 `Finset.sup'` 构造非空有限路径族的真实最大值。`maximum_exceeds_eq` 证明“最大值超过阈值”与“存在一条路径超过阈值”的事件完全相等。因此 `finite_maximum_exponential_tail` 得到相同的最大值尾界，并证明该事件可测。

`pathSum` 使用 `List.map` 和 `List.sum` 定义路径上的实际有限延迟和，允许路径列表出现重复顶点。`pathSum_measurable` 从各顶点延迟的可测性证明路径和可测。`finite_path_sum_tail` 将这些定义代入最大值尾界。

空路径族的存在事件自然为空；实数最大值接口明确要求路径族非空，避免人为指定空集的最大值。

## 依赖与边界

实际检查的官方 API 包括：

- `MeasureTheory.mul_meas_ge_le_integral_of_nonneg`。
- `MeasureTheory.measureReal_biUnion_finset_le`。
- `Finset.measurableSet_biUnion`。
- `Finset.lt_sup'_iff`。

代码需要为每条路径提供指数可积性和 MGF 上界。本模块没有证明时钟过程、停止时间、条件独立性或这些输入矩界；也没有证明无限路径族、尾积分期望界、完整 CA 的灭绝时间或 `Θ` 结论。它只补全“实际单路径积分矩界到有限最大路径概率尾界”这一段。

源码不使用 `sorry`、`admit` 或自定义公理。依赖版本和最终编译、公理审计由分析工程的验证记录提供。
