# 几何块尾界推出真实期望上界

> 2026-10-13 续做：此文件保留自然数值版本。新增 `ExtendedBlockTail.lean` 已处理 `T:Ω→ℕ∞`，先从几何尾界证明扩展期望有限，再推出 `μ{T=∞}=0`。旧版本关于扩展接口尚未完成的描述是历史状态；当前覆盖与统一验收见 `../../PROGRESS_2026-10-13.md` 和 `../../audit/analysis-validation.json`。本源码已迁移新版 module 格式，完整环境仍有依赖本地改动提示。

文件：`BlockTail.lean`。使用 mathlib 的真实测度、非负 Lebesgue 积分、Bochner 积分、可测性、无穷和与几何级数接口。

## 定理接口

给定任意测度空间、测度 `μ`、可测的自然数值随机变量 `T`，以及整数块长 `b ≥ 1`。唯一概率界前提是：对每个整数 `j ≥ 0`，

`μ {ω | j*b < T ω} ≤ (1/2)^j`。

由此证明非负扩展期望 `∫⁻ T dμ ≤ 2*b`，证明其有限性，进一步推出实数转换后的 `Integrable`，最后证明真正 Bochner 期望 `∫ (T:ℝ) dμ ≤ 2*b`。

这个结论对概率测度当然成立；实际形式比概率测度假设更强，任意满足上述尾测度界的测度均可使用。没有预先要求期望或实数积分有限。

## 证明路线

1. `truncation_le_blocks`：对自然数 `t,b,n`，归纳证明 `min(t,n*b) ≤ ∑_{j<n} b*1{j*b<t}`。
2. `value_le_block_tsum`：取 `n=t`，使用 `b≥1` 和有限和不超过非负无穷和，得到逐点支配 `T ≤ ∑'j b*1{j*b<T}`。
3. `blockWeight` 是真实事件的指示函数乘常数，证明可测性，并用 `lintegral_indicator_const` 证明其积分是 `b * μ{T>j*b}`。
4. 用真实 `lintegral_tsum` 交换非负积分与无穷和；这一接口本身允许积分为无穷，不需要假设可积性。
5. 对尾界逐项比较，再使用 mathlib 已证明的几何级数 `∑'j (1/2)^j = 2`，得到 `lintegral_le_two_blocks` 和 `lintegral_lt_top`。
6. 使用 `hasFiniteIntegral_iff_ofReal` 和可测性，得到 `integrable_realCast`；随后通过 `integral_eq_lintegral_of_nonneg_ae` 和有限 ENNReal 的 `toReal` 单调性，得到 `integral_le_two_blocks`。

## 完成边界

已于 2026-10-13 使用 Lean 4.35.0-rc4、mathlib 提交 `54c01c3314d33d15d77893cbe4e0472ff26bb34d` 实际编译，退出码 0，Lean 源码检查没有错误或警告。编译命令为在 `formal/analysis` 目录运行 `../.tools/lean-4.35.0-rc4-windows/bin/lake.exe env lean MathResearchAnalysis/BlockTail.lean`；Lake 层另会显示依赖仓库有本地改动的状态提示。

全部 9 个公开定理另经同一工具链的 `#print axioms` 实际审计，退出码 0。每个定理仅依赖标准 `propext`、`Classical.choice`、`Quot.sound`；没有 `sorryAx` 或本项目自定义公理。源文件没有 `sorry` 或 `admit`。

本模块不证明 Markov 块重启产生几何尾界，也不建立 CA 随机变量或 Poisson 过程。`T : Ω → ℕ` 本身表示每个样本都具有有限自然数值；允许恢复时间为无穷的模型仍需另建扩展随机变量接口并证明几乎处处有限。`b` 的 `O(n²)` 量级仍需模型层证据。本模块不单独构成 CA 的 `Θ(n²)` 定理。

## 所用 mathlib 接口来源

- [非负积分的无穷和接口](https://github.com/leanprover-community/mathlib4/blob/54c01c3314d33d15d77893cbe4e0472ff26bb34d/Mathlib/MeasureTheory/Integral/Lebesgue/Add.lean)：`lintegral_tsum`。
- [指示函数积分接口](https://github.com/leanprover-community/mathlib4/blob/54c01c3314d33d15d77893cbe4e0472ff26bb34d/Mathlib/MeasureTheory/Integral/Lebesgue/Basic.lean)：`lintegral_indicator_const`。
- [几何级数](https://github.com/leanprover-community/mathlib4/blob/54c01c3314d33d15d77893cbe4e0472ff26bb34d/Mathlib/Analysis/SpecificLimits/Basic.lean)：`ENNReal.tsum_geometric_two`。
- [Bochner／非负积分转换](https://github.com/leanprover-community/mathlib4/blob/54c01c3314d33d15d77893cbe4e0472ff26bb34d/Mathlib/MeasureTheory/Integral/Bochner/Basic.lean)：`integral_eq_lintegral_of_nonneg_ae`。
