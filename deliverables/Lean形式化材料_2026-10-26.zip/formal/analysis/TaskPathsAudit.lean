import MathResearchAnalysis.TaskPaths

#print axioms MathResearchAnalysis.TaskPaths.System.mem_paths_iff_legal
#print axioms MathResearchAnalysis.TaskPaths.System.paths_nonempty
#print axioms MathResearchAnalysis.TaskPaths.System.path_length
#print axioms MathResearchAnalysis.TaskPaths.System.path_inTaskLayers
#print axioms MathResearchAnalysis.TaskPaths.System.weight_eq_forward_sum
#print axioms MathResearchAnalysis.TaskPaths.System.path_weight_le_completion
#print axioms MathResearchAnalysis.TaskPaths.System.completion_attained
#print axioms MathResearchAnalysis.TaskPaths.System.completion_eq_path_max
#print axioms MathResearchAnalysis.TaskPaths.System.paths_card_le
#print axioms MathResearchAnalysis.TaskPaths.System.mem_terminalPaths_iff
#print axioms MathResearchAnalysis.TaskPaths.System.terminalPaths_nonempty
#print axioms MathResearchAnalysis.TaskPaths.System.terminalMaximum_eq_path_max
#print axioms MathResearchAnalysis.TaskPaths.System.terminalMaximum_exceeds_iff
#print axioms MathResearchAnalysis.TaskPaths.System.terminalPaths_card_le
#print axioms MathResearchAnalysis.TaskPaths.System.terminalPaths_inTaskLayers
#print axioms MathResearchAnalysis.TaskPaths.System.predecessor_completion_le
#print axioms MathResearchAnalysis.TaskPaths.System.terminalMaximum_monotone
#print axioms MathResearchAnalysis.TaskPaths.System.prefixMaximum_eq_last
#print axioms MathResearchAnalysis.TaskPaths.System.mem_allPaths_iff
#print axioms MathResearchAnalysis.TaskPaths.System.allPaths_nonempty
#print axioms MathResearchAnalysis.TaskPaths.System.layerMaximum_eq_path_max
#print axioms MathResearchAnalysis.TaskPaths.System.layerMaximum_exceeds_iff
#print axioms MathResearchAnalysis.TaskPaths.System.allPaths_card_le
