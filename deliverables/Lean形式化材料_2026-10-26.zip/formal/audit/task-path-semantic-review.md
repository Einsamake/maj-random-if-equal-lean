# TaskPathTail 独立语义审查

审查日期：2026-10-13。此次只读检查 `TaskPathTail.lean`，并沿调用读取 `TaskPaths.lean`、`PathTail.lean`、`NonnegativeMoment.lean`、既有 `ConditionalMoment.lean` 和 `FiniteTail.lean`；另检查 `StoppingPath.lean` 的输入边界。**此记录是命题与证明链的语义检查，不提供 TaskPathTail 的编译或公理审计结论。** 实际构建结果以统一验证日志为准。

## 结论

在本次读取的源码中，未发现把前缀可积性、固定路径完整指数矩、路径最大恒等式或路径数界作为新假设的循环。该模块得到的是明确单步条件矩输入下，真正递归定义的有限任务表最大值的条件性尾界。它尚未实例化实际 Poisson 时钟、强 Markov 性或二维交替颜色 CA。

## 层编号与路径权重

- `TaskPaths.paths k v` 的路径长度是 `k+1`；若与候选稿的正层数 `r` 对照，应取 `r=k+1`。`delay 0` 对应候选稿第 1 层，`completion delay 0` 是第一个正任务层，不是全零初始化层。
- 路径逆序保存。对 `[v₂,v₁,v₀]`，`pathWait` 的第 0、1、2 项分别是 `delay 0 v₀`、`delay 1 v₁`、`delay 2 v₂`。同一顶点可重复出现，其不同层因子不会混同。
- `pathWait` 在 `v::q` 中仅于 `i=q.length` 选择新末层顶点，其余有效索引递归到旧路径。`prefixSum_congr` 核对全部旧有效索引；`prefixSum_pathWait` 由列表归纳证明前向前缀和等于 `System.weight`。超过路径长度的值没有进入任何所用前缀。
- 末层尾界系数为 `|tasks| d^k 2^(k+1)`。取 `r=k+1`、`d=4` 和 `|tasks|≤N` 后，才得到候选稿形式 `N 4^(r-1) 2^r`；这些具体参数及不等式不能省略实例化核对。

## 固定性及概率证明链

`M`、前驱集合、末层任务集合和有限列表路径都在采样前固定；它们的类型不是 `Ω→...`。等待因子和完成时间才依赖样本 `ω`。对每个事先固定的列表分别应用矩定理，然后有限并集；没有对依样本选出的最大路径直接使用固定路径条件矩，也没有使用路径间独立性。

证明链是：单步 `hknown`、`hwaitInt`、`hconditional` → `NonnegativeMoment` 的前缀可积及固定路径矩 → `FiniteTail` 的 Markov/有限并集 → `TaskPaths` 已证明的最大恒等式与路径数界。`degree` 只约束实际前驱集合基数，不是最终路径数结论；`hconditional` 只规定单个指数因子的条件期望，不是完整前缀矩。路径计数与矩互不循环。

## 末层及所有前层最大值

`terminal_maximum_tail` 针对输入的有限末层标签集合；其事件转换使用已证明的 `terminalMaximum_exceeds_iff` 和真实路径长度。`prefix_degree_half_tail` 逐样本调用 `prefixMaximum_eq_last`，输入是所有等待非负，以及每个前层任务存在下一层任务后继。该输入保证最大值单调，足以推出前所有层最大等于末层最大；这里没有证明严格增长，也不需要严格增长。

## 尚未实例化的边界

1. `completion` 是对全部 `V` 定义的泛型 max-plus 递推表。审查后补入 `InTaskLayers` 定义及 `path_inTaskLayers`、`terminalPaths_inTaskLayers`：从末层顶点属于 `tasks k` 和前驱闭合条件，实际证明每条枚举路径的所有祖先属于相应任务层。前驱闭合条件的精确形式为：若 `v∈tasks(j+1)` 且 `u∈predecessors j v`，则 `u∈tasks j`。此通用桥接已证明；具体二维棋盘颜色满足该闭合条件仍未实例化。不能因此称已经连接实际 CA 调度。
2. 非空前驱、非空各层任务、后继覆盖和度数 `≤4` 均需从具体有限格点及二分颜色证明。抽象度数输入不能表述为实际四邻格实例已经完成。
3. `hknown`、每个单步指数因子的 `hwaitInt` 和其条件 MGF `hconditional` 仍是概率输入。`StoppingPath` 另外证明真实停时 σ-代数下的等待可测性，但 TaskPathTail 当前并未由具体时钟模型构造这些输入。有限实值等待、严格下一响铃、强 Markov 和条件 Exp(1) 分布仍需建立。
4. 本模块不提供 PW 删更新、零温极限、CMST、随机链的两向比较或完整恢复时间主定理。不能把此次尾界桥接表述为无条件 CA Θ(n²) 已由 Lean 验证。

本次只读审查没有修改 `TaskPathTail.lean`；另按续做任务补充了 `TaskPaths.lean` 的通用前驱闭合定理。实际编译与公理审计结果以统一验证日志为准。
