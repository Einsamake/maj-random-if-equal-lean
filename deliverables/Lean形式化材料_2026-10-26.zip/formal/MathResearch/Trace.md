# 有限确定性更新字：形式化范围

本模块使用 Lean 4 标准库 `Std`。`Trace.lean` 已用本地 Lean 4.35.0 实际编译通过：退出码为 0，编译输出为空，无错误或警告。编译命令在 `formal` 目录运行本地工具包中的 `lean.exe MathResearch\Trace.lean`。统一工程构建和公理依赖审计由整个形式化工程的验证材料提供。

## 执行与允许交换

- `execute update word initial` 使用 `List.foldl` 从左到右执行带标签的确定性更新。
- `Commutes update a b` 明确要求两个更新在**每个状态**上的复合结果相同。
- `execute_adjacent_swap` 证明：在任意不变的前缀和后缀中，把两个相邻且可交换的更新调换，最终状态保持不变。
- `SwapEquivalent independent` 是独立定义的归纳关系，其构造子只包含自反、允许的相邻交换、对称和传递。
- `execute_eq_of_swapEquivalent` 证明：若 `independent a b` 的每个允许对都确实满足 `Commutes update a b`，那么由有限次允许交换产生的任何重排都保留执行结果。
- `swapEquivalent_perm` 证明允许交换会保留全部更新出现次数；`swapEquivalent_move_to_front` 证明一个事件可以跨过独立事件前缀而移到最前。

因此，执行保持定理并没有预先假设“这些重排的执行结果相同”。需要调用方提供的是局部的函数交换证据，以及由关系构造子形成的重排证据。

## 保持冲突次序的排列

这一部分也已经编译通过。`Before a b word` 定义为 `[a, b]` 是 `word` 的有序子序列。`PreservesConflictOrder` 要求每个没有声明独立的事件对保留源序列中的先后次序。

`swapEquivalent_of_perm_preserving_conflicts` 的假设是：源序列的事件标识不重复（`List.Nodup`），两个序列互为排列（`List.Perm`），且保留所有冲突事件对的次序。结论是这两个序列满足 `SwapEquivalent`。

证明从目标序列头事件开始：在源序列中找到它；证明它前面被跨越的每个事件都独立，否则次序保持会迫使目标头事件再次出现在目标尾部，违反唯一性；逐个交换把它移到源序列最前；删除双方同一头事件后递归证明剩余事件。结论中的允许交换等价没有被用作前提。

`execute_eq_of_perm_preserving_conflicts` 把上述纯组合定理与允许对的实际函数交换证据合并，得到两种执行的最终状态相同。

唯一性要求针对**更新事件 ID**。同一个格子可以更新多次，只需为各次更新分配不同 ID，并通过 `update eventId` 指定对应的更新函数。基础的有限交换执行保持定理本身不需要事件标识唯一。

## 单格更新的充分条件

`cellUpdate rule i` 先从旧配置计算 `rule i`，然后只写格子 `i`。`ReadsOnly reads rule` 要求规则的输出只依赖声明的读取集合。

`cellUpdates_commute_of_read_write_disjoint` 证明以下充分条件：格子不同，更新 `i` 不读取 `j`，更新 `j` 不读取 `i`。两者可以读取同一个第三格子，因为这个第三格子不在任何一次更新的写集合里。

`cellUpdates_commute_of_nonadjacent` 把这个结论用于对称邻接关系：若规则只读本格及邻格，不同且不相邻的单格更新可交换。该前提不适用于规则暗中读取远处格子、同时写多个格子、或依赖外部随机/时间状态的实现。

## 没有覆盖

- 任意排列并不会自动满足 `SwapEquivalent`；有冲突的更新可能改变结果。更强的排列定理需要唯一事件标识和冲突次序保持证据。
- 无限执行、调度公平性、概率分布、随机独立性、系统收敛和终止没有在本模块中建模。
- 任何渐近时间界、`Θ` 主张及加速比都没有在本模块中证明。
- 有限交换关系不证明原始 CA 候选方案的全部结论；它只给出有限确定性轨迹比较的一块严格基础。

源码关闭自动隐式变量（`autoImplicit false`），不使用 `sorry`、`admit` 或自定义公理。函数外延性和冲突次序证明中的经典反证通过 Lean 的标准逻辑基础使用；这不等于声称整个工程不依赖 Lean 的标准逻辑公理。
