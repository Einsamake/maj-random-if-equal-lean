# 局部 readiness 递归的确定性保序

文件：`Readiness.lean`。导入本项目 `Scheduling.lean` 和 `Dynamics.lean`，仅依赖 Lean 4 标准库，不依赖 Mathlib。

## 模型与假设

`System V` 的显式字段为：

- `neighbours : V → List V`：每格的有限邻格列表，允许列表中重复出现邻格。
- `nonempty`：每个列表非空，排除孤立格。
- `symmetric`：相邻关系对称。
- `nextRing : V → Nat → Nat`：从局部 readiness 时刻选择完成时刻。
- `later`：对任意格和 readiness 时刻 `r`，严格满足 `r < nextRing v r`。

不假设 `nextRing` 单调，不假设全局或局部等待时间独立。所有时间均为自然数；本模块证明顺序骨架，未构造连续时间 Poisson 时钟。

递归为 `completion 0 v = 0`、`ready j v = maximum (neighbours v 的 j 层完成时刻)`、`completion (j+1) v = nextRing v (ready j v)`。其中最大值是真正的有限列表最大值，不是额外给定的上界。第一层等于 `nextRing v 0`，已在 `completion_one` 中证明。

## 核心顺序结论

- `predecessor_lt`：邻格 `u` 的前层完成时间严格早于 `v` 的后层完成时间。
- `same_site_two_steps`：同格第 `j` 层严格早于第 `j+2` 层；证明从非空列表选择一个邻格，沿对称边往返。
- `along_fixed_path`：沿任意事先给定的有限邻格路径，完成时刻严格保序，允许路径重访同格。
- `same_site_even_gap`、`same_site_even_order`：同格任意正偶数层差均严格保序。
- `neighbour_odd_gap`、`neighbour_odd_order`：邻格任意正奇数层差均严格保序。
- `same_site_even_no_reuse`：同格不同偶数差层不能复用相同完成时刻。

## 实际任务子集与虚拟条目

为简化递归，完成表在每层的全部顶点上定义。实际交替任务通过 `Selected colour phase j v` 筛选：层数为正，且该格颜色等于该层活动色。`layerColour_eq_activeColour` 严格证明这里的奇偶颜色公式与 `Dynamics.activeColour` 相同，第一层活动色为 `!phase`。

对具体二分图应用任务结论时，必须提供邻格异色证据 `hBipartite`。这条证据没有被默认为成立。

- `selected_predecessor`：选中第 `j+1` 层任务的全部邻格前驱均是选中第 `j` 层任务（`j>0`）。所以计算实际任务时，不会引入同层中其他颜色的虚拟条目；第一层只使用共同的零层基线。
- `selected_conflict_order`、`selected_conflict_order_iff`：任意两个选中且同格或邻接的任务，完成时刻的严格顺序与逻辑层的严格顺序一致。
- `selected_same_site_injective`、`selected_same_site_no_reuse`：选中同格任务的完成时刻对层数单射。
- `selected_event_injective`：以 `(site, completionTime)` 为确定性事件标识，不同选中任务无法复用同一个标识。不同格允许同时完成。

这些结论只作用于 `Selected` 子集。未把全部顶点、全部层的虚拟条目当作实际时钟事件；也没有宣称同格相邻两层的虚拟时间一定保序。

## 验证与完成边界

已于 2026-10-13 使用 Lean 4.35.0 实际编译全部定义与定理，退出码 0，输出为空（无错误、无警告）。在 `formal` 目录运行 `.tools/lean-4.35.0-windows/bin/lake.exe env lean MathResearch/Readiness.lean` 可复核。

全部 23 个公开定理均另经 `#print axioms` 实际审计：`completion_zero`、`completion_succ` 和 `ready_lt_completion` 无公理依赖；`exists_neighbour` 仅依赖 `propext`；其余依赖仅为标准 `propext` 和 `Quot.sound`。没有 `Classical.choice`、`sorryAx` 或本项目自定义公理，源文件没有 `sorry` 或 `admit`。

未形式化连续实数时间、停时、强 Markov 性、事件具有独立平局标记、随机删更新、路径指数矩、Poisson 尾概率或期望恢复时间。本模块的自然数 `nextRing` 假设只服务于严格顺序的抽象骨架；将其应用于真正连续时间过程仍需另外证明相应接口。
