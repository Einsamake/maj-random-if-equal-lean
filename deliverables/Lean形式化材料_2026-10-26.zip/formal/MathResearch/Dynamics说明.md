# 确定性同步／交替拆链模块

文件：`Dynamics.lean`。只导入 Lean 4 的 `Std`，不依赖 Mathlib。

## 模型与假设

`State V = V → Bool`，`V` 是任意类型，可以为空、有限或无限。`BipartiteSystem` 的显式字段为：

- `colour : V → Bool`：两个棋盘颜色。
- `update : Nat → V → State V → Bool`：已经固定随机标记之后的确定性局部更新。时间参数为更新完成后的整数时刻，首次更新参数为 1。
- `opposite_local`：若两个输入状态在被更新格的全部异色坐标相同，则更新输出相同。这个字段同时禁止读取中心旧值及其他同色旧值。
- `zero_update`：对任意格、任意时间，输入全零状态时输出零。

该接口用“全部异色坐标上的等同性”表达二分局部性。它允许规则只读取异色坐标的一个子集（例如四个最近邻），并未自行证明具体二维多数规则满足这些字段。

## 时间约定

`activeColour c 0 = c`，之后每一步翻转。交替链 `c` 的第一槽更新 `!c`，这与候选稿的 `χ(v) + t = c (mod 2)` 一致。同步链和两条交替链的初态相同，且共享相同的 `update t v`；不涉及标记的独立性。

## 已写入的定理

- `splitting_succ`：对所有 `t ≥ 0`，交替链在 `t+1` 时的活动色等于同步链在 `t+1` 时的状态，未活动色等于同步链在 `t` 时的状态。
- `splitting`、`active_value`、`inactive_value`：上述恒等式的 `t ≥ 1`／`t-1` 形式。
- `synchronous_zero_step`、`alternating_zero_step` 及 `*_zero_persists`：全零一步吸收及任意以后时刻的吸收。
- `synchronous_zero_implies_alternating_next_zero`：同步链在 `t` 时全零，则每条交替链在 `t+1` 时全零；包含 `t=0`。
- `both_alternating_zero_implies_synchronous_zero`：两条交替链在同一时刻全零，则同步链当时也全零。
- `eventually_zero_iff`：同步链存在有限归零时刻，当且仅当两条交替链都存在有限归零时刻。
- `FirstZero`、`firstZero_exists`、`firstZero`、`firstZero_spec`：以有限归零证据定义首次归零时刻，并证明其最小性。最小自然数存在性的辅助证明在本模块中完成，没有引入自定义公理。
- `absorption_times`、`firstZero_bracket`、`finite_absorption_comparison`：在有限首次归零时刻存在的条件下，严格证明 `T ≤ max τ₀ τ₁ ≤ T+1`。

## 完成边界

已于 2026-10-13 使用 Lean 4.35.0 实际编译，退出码为 0，编译输出为空（无错误、无警告）；不使用 `sorry`、`admit` 或自定义 `axiom`。检查方法是在 `formal` 目录运行 `.tools/lean-4.35.0-windows/bin/lean.exe MathResearch/Dynamics.lean`。

这里的有限性是假设或由其他有限性证据导出的结论。没有证明二维多数规则的实例化、Poisson 时钟、概率比较、期望恢复时间、外部主定理或 `Θ(n²)`。`firstZero` 使用 Lean 的标准 `Classical.choose`，其选择对象存在性已在模块内部证明。

## 实际公理审计

把源文件连同 `#print axioms` 命令经标准输入重新交给同一 Lean 4.35.0 检查，退出码为 0。主要定理的实际依赖如下：

| 定理 | Lean 标准逻辑依赖 |
| --- | --- |
| `splitting_succ` | `propext` |
| `splitting` | `propext`, `Quot.sound` |
| `synchronous_zero_persists`、`alternating_zero_persists` | `propext`, `Quot.sound` |
| `synchronous_zero_implies_alternating_next_zero` | `propext`, `Quot.sound` |
| `both_alternating_zero_implies_synchronous_zero` | `propext` |
| `eventually_zero_iff` | `propext`, `Quot.sound` |
| `firstZero_exists`、`firstZero_spec` | `propext`, `Classical.choice`, `Quot.sound` |
| `absorption_times` | `propext`, `Quot.sound` |
| `firstZero_bracket`、`finite_absorption_comparison` | `propext`, `Classical.choice`, `Quot.sound` |

没有 `sorryAx`，没有本项目自定义公理。上述标准逻辑依赖与结构字段中的显式数学假设需要区分：后者是每次应用定理必须提供的模型证据，并未被登记成新的公理。
