# 二维四邻格具体模型与方形封闭性

文件：`Grid.lean`。导入本项目的 `Dynamics.lean` 和 `Majority.lean`，二者仅依赖 Lean 4 标准库；不依赖 Mathlib。

## 实际模型

`Site = Int × Int`，分别定义北、东、南、西四个最近邻。棋盘颜色为 `decide ((x+y) % 2 = 0)`，并用整数算术证明四个邻格均与中心异色。

`Marks = Nat → Site → Bool` 表示已固定的平局标记。更新确实读取四邻格状态的多数：1 的个数大于 2 时输出 1，小于 2 时输出 0，等于 2 时才使用对应标记。更新不读取中心旧值。

`system marks : BipartiteSystem Site` 的两个证明字段不是额外假设：异色局部性由四邻格异色定理和实际更新定义证明；全零吸收由实际多数规则的 `zero_fixed` 证明。由此得到具体模型的 `splitting`、`absorption_times` 和 `finite_absorption_comparison` 推论，首次归零时刻的有限存在性仍按定理前提处理。

## 方形封闭性

`Inside n (x,y)` 表示 `0 ≤ x < n` 且 `0 ≤ y < n`，即半开整数方形 `{0,…,n-1}²`，允许 `n=0`。`Supported n state` 表示方形外各格均为 0。

证明依次包含：

1. 对六组不同方向的邻格，若两个邻格都在方形内，则中心也在方形内；每组使用实际整数不等式证明。
2. `inside_neighbours_le_one`：方形外格最多有一个内部邻格。
3. `neighbour_ones_le_one`：状态在方形外全零时，每个外格看到的四邻格至多一个 1。
4. `update_supported`：真实多数更新仍使方形外全零；此步调用已核验的 `Majority.at_most_one`。
5. `singleSiteUpdate_supported`、`synchronous_supported`、`alternating_supported`：单格更新、任意时刻同步演化和任意颜色交替演化均保留同一个方形包围范围。

## 验证与完成边界

已于 2026-10-13 使用 Lean 4.35.0 实际编译，退出码 0，输出为空（无错误、无警告）。在 `formal` 目录运行 `.tools/lean-4.35.0-windows/bin/lake.exe env lean MathResearch/Grid.lean` 可复核。

另把源码及本文件全部 20 个公开定理的 `#print axioms` 命令经标准输入交给同一 Lean 检查，并额外审计 `system`；退出码 0。实际依赖只包含 Lean 标准 `propext`、`Quot.sound`、`Classical.choice`，其中 `inside_of_state_true` 不依赖任何公理；`system`、四邻格异色定理、`splitting` 和 `absorption_times` 仅依赖 `propext`、`Quot.sound`。没有 `sorryAx`，没有 `sorry`、`admit` 或自定义 `axiom`。

这些都是任意固定标记下的确定性结论。没有为标记添加概率分布或独立性，没有形式化 Poisson 时钟、期望、外部文献定理、有限时间吸收概率或 `Θ(n²)`。方形封闭性不自行构造有限状态空间与无限状态空间之间的完整等价，也未处理任意平移方形的接口。
