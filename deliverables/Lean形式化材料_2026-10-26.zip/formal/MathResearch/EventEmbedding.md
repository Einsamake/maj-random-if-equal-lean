# 有限带标记事件的排名与槽排序嵌入

`EventEmbedding.lean` 只使用已有的 `Trace`、`Scheduling` 模块及它们导入的 Lean 标准库。已在 Lean 4.35.0 下实际编译通过：退出码 0，输出为空，无错误或警告。它构造实际的 `List.mergeSort` 目标序列，不留下“排序目标存在”的未证明条件。

## 事件、冲突与槽

事件标签是唯一 ID。元数据函数给出 `site event`、`color event : Bool`、`rank event : Nat`。同格允许出现许多不同 ID 的更新。

`Conflict site adjacent a b` 明确定义为“同格或邻格”；`Independent` 是其否定。`ConflictRanksIncrease` 表示源序列中每一对先后出现的冲突事件满足严格 rank 增长。

`eventSlot` 复用 `Scheduling.slot`：`true` 色取 `2 * rank - 1`，`false` 色取 `2 * rank`。`conflicting_slots_increase` 从实际 rank 严格增长调用 `slot_strict_of_rank_strict`，推出冲突事件的槽严格增长。

## 构造排序并证明执行相等

`sortBySlot` 用槽的非严格比较执行归并排序。模块证明：

- `sortBySlot_perm`：目标是源序列的真实排列，保留全部事件出现次数。
- `sortBySlot_sorted`：目标满足 `List.Pairwise` 槽非递减。
- `sortBySlot_preserves_conflicts`：源冲突事件的 rank 严格增长时，排序保留所有冲突事件对的先后次序。
- `sortBySlot_swapEquivalent`：结合源 ID 唯一性与 `Trace` 的组合定理，推出排序由允许的相邻交换组成。
- `execute_eq_sortBySlot`：若允许对确实交换，源序列与排序序列的最终状态相同。

第三步使用标准库归并排序的有序对子序列保持定理；第四步使用独立证明的冲突次序排列定理。整个证明没有把目标交换等价或最终执行相等作为前提。

## 实际排名算法也已接通

`rankChronological` 构造带 rank 的事件字：把最早事件在前的源序列反转，调用 `Scheduling.annotate`，再反转回来。每个新事件的 rank 是所有更早冲突事件 rank 的最大值加一。

已证明的算法性质包括：原 ID 字保持、唯一性保持、每个 rank 为正，以及全部冲突事件对的 rank 严格增长。最后一项从实际算法证明，而非假设。

`execute_eq_generated_slot_sort` 因而从原始有限事件字出发，证明它与**实际排名算法加实际槽排序**后的执行最终状态相同。这个强版本不再要求调用方提供 `ConflictRanksIncrease`。它仍明确要求事件 ID 唯一、邻接可判定且对称，以及允许更新对的函数交换证据。

## 固定事件标记的局部规则

`markedCellUpdate site rule event` 先用该事件 ID 对应的 `rule event` 读取旧配置，只写 `site event`。不同事件可以使用不同的固定规则；固定的随机标记、阈值等参数可以包含在 `rule event` 中。

`MarkedReadsOnly` 要求每个事件规则只读取本格及邻格。`marked_updates_commute` 从这个明确的读取条件和邻接对称性，证明不同且不相邻格子的事件更新确实交换。

`execute_marked_eq_sortBySlot` 与 `execute_marked_eq_generated_slot_sort` 把局部交换证明代入排序证明。后者给出完整的有限确定性结论：原始事件字与算法生成的排名/槽排序事件字具有相同最终配置，前提仅包括固定的局部规则、对称且可判定的邻接和唯一事件 ID，不再预设 rank 增长或交换结果。`execute_marked_eq_sortBySlot_at` 显式给出最终配置在每个格子上的相等。

这是一条对每个固定标记实现成立的确定性结论。它没有建立随机标记的概率分布、独立性或耦合分布保持。

## 每槽的有限批次

`slotBatch` 从有限字中选出同一槽的事件，并保持源顺序。

- `slotBatch_same_color`：当成员 rank 为正，同槽事件同色。
- `slotBatch_pairwise_independent`：源冲突 rank 严格增加时，同槽事件两两独立。
- `slotBatch_sites_nodup`：同槽没有重复写入的格子。

实际排名算法已经证明所需的正 rank 和冲突 rank 增长，因此这些批次定理可以直接用于其输出。模块没有另外建模同槽批次的同步执行操作。

## 范围与检查

以上结论针对有限事件字和固定的确定性更新函数。它们不涵盖无限执行、调度公平性、随机时钟概率律、概率尾界、收敛/终止、期望时间或 `Θ` 结论。模块也不声称不同排序下每个中间的全局配置都相同；它证明全部有限事件执行完后的配置相同。

源码关闭自动隐式变量，不使用 `sorry`、`admit` 或自定义公理。函数外延性及经典反证使用 Lean 标准逻辑基础；具体公理依赖由统一工程审计列出。
