# 原研究报告（2026-10-13）

这里保留原始报告、可编辑 Word、附录及复现记录。本轮仅改变位置，未改写原内容。它们包含 CA 候选论证及回归部分界，**不表示完整主定理已通过 Lean**。当前状态从根目录 [README](../../README.md) 进入。

- [REPORT.md](REPORT.md)：原研究报告。
- [数学开放问题证明尝试记录.docx](数学开放问题证明尝试记录.docx)：原可编辑 Word。
- [TECHNICAL_APPENDIX.md](TECHNICAL_APPENDIX.md)：推导、审查及失败路线。
- [REPRODUCE.md](REPRODUCE.md)、[SEARCH_LOG.md](SEARCH_LOG.md)：原复现及检索。
- `MANIFEST.json`：原交付的历史清单，路径相对当时根目录，不是当前快照。

原稿中的 `research/...` 均相对工作区根目录。生成脚本现位于 `scripts/` 且路径已适配：`scripts/build_report.py` 输出这里的 Word 和附录；`scripts/export_word.ps1` 新预览输出为这里的 `qa/report.pdf`。本轮只检查路径，未重新生成或排版 Word。

原包在 `archive/packages/研究记录与验证材料.zip`；原渲染 PDF 在 `archive/qa/report_2026-10-13.pdf`。页面 PNG 为可再生成预览，已经清理。更新 Word 仍须实际渲染。
