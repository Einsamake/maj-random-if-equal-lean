# 选题与文献核验记录

北京时间2026年10月13日，两轮记录（含03:20唤醒后复核）。只以一手论文、会议论文页或原作者公开稿判断问题和数学前提。未联系作者或其他人，也未发布任何稿件。

## 兴趣与筛选

依据此前对话记录，优先筛选脉冲预测编码、局部通信与细胞自动机、在线学习与机器学习理论。三个研究代理分别检索候选，主代理集中选题和审查。选择维数低且陈述明确的问题，不以“容易陈述”保证“容易证明”。

## 主要实际检索与结论

1. Open Problem Data Selection for Regression Tasks。COLT2025会议页及原稿确认问题来源。https://proceedings.mlr.press/v291/hanneke25e.html
2. Exact Recovery Thresholds for Weighted Data Selection in Vector Valued Linear Regression，2608.30254，13/8。先读v1，随后在arXiv摘要页发现v2（2026-10-02），改为核对Conjecture6.5、Theorem6.4、LemmaE.1、LemmaE.4、AppendixE.6及F。v2仍把13/8和5/4列为未解决。https://arxiv.org/html/2608.30254v2
3. Exact Risk Ratios for Weighted Data Selection in Linear Regression，2608.28007。发现标量小情形(3,4)、(4,5)已有新结果，未将它们选为开放目标。https://arxiv.org/abs/2608.28007
4. DiffPC ICLR2026与Frieder Lukasiewicz ICML2022。记录未来问题及算法/梯度形式的审查信号，最终未选择范围较宽的训练收敛问题。具体来源和边界在research/predictive_coding/proof_attempt.md。
5. Maj Random If Equal quadratic，Self stabilisation Question7.4。原作者论文确认同步规则、有限扰动、最坏期望时间定义、O(n³)和平方猜想。https://arxiv.org/html/2101.12682v3
6. Marcovici self organisation 2025。作者综述仍介绍相关三次上界。它支持问题背景，不证明2026年没有任何新结果。https://marcovici.perso.math.cnrs.fr/Publications/Marcovici_ESAIM2025.pdf
7. Peres Winkler Can Extra Updates Delay Mixing。实际读取作者PDF及Theorem1.1，核对随机更新序列及子序列允许、最大初态和单调性条件；Section3粗扫描比较不直接给需要的平方界。https://www.microsoft.com/en-us/research/wp-content/uploads/2017/01/1112.0603v1.pdf
8. Fontes Schonmann Sidoravicius Theorem1.3 alpha gamma。作者仓库全文索引读到定理公式，完整PDF经web和原始下载失败。未把“只读搜索摘要”称为完整原文核验。该来源后来降为历史背景。https://repositorio.usp.br/directbitstream/8f023251-c94c-4a4a-9f93-aa0e68d4df12/1195044.pdf
9. CMST1007.3599。实际完整读取HTML设置与Section3.2 Theorem2式(3.4)，确认虽然题名涉及3D，此处定理为2D固定同色边界、反色实心方岛、rate1热浴更新的平方上、下界。作为当前候选证明的主依赖。https://arxiv.org/html/1007.3599v2
10. 检索Maj Random If Equal Peres、synchronous zero temperature droplet quadratic、bounded degree alternating Glauber censoring、systematic scan spectral independence。未发现同一证明或解决公告，但范围有限。一般局部时钟调度可能有经典文献来源，不声明辅助技术原创。
11. 检索5/6 data selection regression、11/6 weighted regression selection及原题名。当前作者稿只给7E/8，未发现相同部分界公告。未把这一点当作原创性认证。

## 检索限制

开放性无法用有限公开检索作绝对证明。作者稿可能有错误，相同结果也可能以不同名称发表。03:20续做已重点核对扫描与局部时钟调度比较；未检出同一结果仍不是新颖性认证。

## 03:20续做的一手文献复核

完整定理、页码、假设和排除理由见research/followup/novelty_review.md。最重要的新增发现是辅助方法有经典来源，已补入候选证明。

12. Liu–Yin arXiv:2111.04044v2，Lemma3.11正是N[e(Δ+1)t/k]^k的Poisson依赖深度界。主代理读取完整HTML核对。https://arxiv.org/html/2111.04044v2
13. Lubachevsky，ComplexSystems1987，作者修正版cs/0502039，局部等待保真模拟异步CA与连续时间Glauber。https://arxiv.org/html/cs/0502039
14. Rajsbaum–Sidi1994，IEEE TPDS5(9)，式(1)、Theorem2.1和SectionIV。max-plus邻层递推与指数处理时间速度已有；其全局独立任务假设与候选共享时钟的固定路径证明有差别。主代理读取机构PDF复核递推及Lemma4.2位置。https://groups.csail.mit.edu/tds/papers/Rajsbaum/RajsbaumSidi94.pdf
15. Guo–Kara–Zhang2018、Gaitonde–Mossel2026、Blanca–Zhang2023/2025及Kwon2026。已核对的现成结果涉及平衡谱隙、额外规模因子或正边缘假设，不直接给候选两向零温吸收迁移。详细来源与定理在新颖性审查稿。
16. 再读FMMT2022的规则(36)、直径定义、Question7.4；再读CMST二维Theorem2及PWTheorem1.1的随机序列许可。未发现候选模型与原问题的关键定义不符。
17. 再读Zhang2608.30254v2的Theorem6.4、Conjecture6.5及AppendixF.5；四原子已有E/2上界，不能把续做四点分类当新开放子类解答。相邻新稿2610.00101为标量五维问题，不是本二维向量三点问题。
