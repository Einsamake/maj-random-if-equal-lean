# 验证材料说明

先读 REPORT.md 看结论和边界；TECHNICAL_APPENDIX.md 保留完整推导和多份独立审查。数学论证没有依赖模型意见投票；脚本用于核验具体代数和构造，不代替全称定理证明。

## 精确检查

以下脚本只使用Python标准库，均已实际运行。

| 脚本 | 核验对象 | 预期结果 |
|---|---|---|
| research/online/exact_examples.py | 六点回归例全部支持及连续权重解析优化 | 三点13/8 四点5/4 |
| research/online/exact_covariance_audit.py | 有理复数star恒等式及200个二维协方差实例 | 全部精确通过 |
| research/online/exact_heptagon.py | 七边形35个支持与显式正权重 | 固定实例C3/E=1/4 |
| research/cellular/check_decomposition.py | 奇偶联结 事件重排 精确删更新比较 | 1200 1200 600份通过 |
| research/cellular/check_inverse_embedding.py | Poisson局部等待逆调度同标记重排 | 840份通过 |
| research/followup/exact_route_barrier.py | 四点例的全部star和完整三角形 | ghost5/6 star3/4 triangle1/2 精确认证 |
| research/followup/exact_triangle_identity.py | 新插值及完整三角形二维公式 | 三边 完全平方 C=0分支精确通过 |

用Python运行相应文件即可，结果JSON与脚本同目录。所有随机检查使用保存的固定种子。精确数域的显示小数不参与符号判断。

## 浮点探索

research/numerical/search_moments.py 需要NumPy。首轮参数为 --samples 1200 --local-steps 600 --seed 20261013。每组5、6、7原子各1200实例，再从各组三个较大值做固定预算局部优化。局部优化没有全局最优或收敛证书，不能据此宣布没有反例。

research/numerical/verify_partial_bound.py 从原始坐标计算协方差，用不同表达式检查部分界。它需要NumPy并导入同目录search_moments。1200矩系统和1200二维点系检查通过。误差容许1e-8，最大关键误差小于4e-10。重复方向的边界另由精确脚本和书面PSD证明处理。

## 本机运行与文档

本次实际使用的Python为 C:\Users\Lenovo\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe。没有使用OpenAI API、没有购买额外计算，也没有联系外部研究者。

build_report.py 从REPORT.md生成可编辑Word，并合并技术附录。两轮更新后的最终Word报告6页已真实渲染并逐页检查；修正了来源另起页造成的大面积空白。qa目录的页面图片和PDF仅用于排版检查，不构成数学验证。交付包不包含qa图片。

## 03:20续做材料

research/followup/ca_clean_proof.md 是当前整洁CA候选稿；ca_fresh_audit.md 是新独立理论重建；novelty_review.md 是一手文献及辅助工具归属核验。regression_fresh_review.md 是回归A—D重新检查、ghost路线屏障、完整三角形投影公式及四点分类。

regression_fresh_checks.py仅用标准库，对两类四点配置的6个固定角度、每组4个三点集做48项确定性浮点检查；实际输出保存在同名.txt中。最大公式差5.55e-16。主代理的两个exact脚本另用高斯有理数无容差核验屏障实例和一般插值恒等式；新JSON结果与脚本同目录。没有重跑首轮随机搜索。

package_materials.py重新生成文件SHA256清单并打包；包内MANIFEST.json对自身以外的文件给出哈希，打包时逐个核对压缩包中的内容。历史阶段记录可能描述当时的较弱下界，当前状态以STATUS.md及报告为准。

## 验收边界

细胞自动机Θ(n²)是本次形成的完整候选证明，内部独立复核暂未发现漏洞，外部审阅和新颖性未认证。回归11/6是部分界，13/8一般猜想仍未解决。任何后续反例或证明缺口都必须反映到STATUS.md和报告，不保留已被推翻的强结论。
