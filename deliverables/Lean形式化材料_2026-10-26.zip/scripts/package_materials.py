"""Package authored reports and reproducible materials; omit preview files."""
from pathlib import Path
import hashlib, json, zipfile

ROOT=Path(__file__).resolve().parents[1]
REPORTS=ROOT/'reports'/'initial-research'
paths=[REPORTS/p for p in ['REPORT.md','数学开放问题证明尝试记录.docx',
       'TECHNICAL_APPENDIX.md','SEARCH_LOG.md','REPRODUCE.md','README.md']]
paths += [ROOT/p for p in ['README.md','STATUS.md','scripts/build_report.py',
          'scripts/export_word.ps1','scripts/package_materials.py']]
paths+=sorted(p for p in (ROOT/'research').rglob('*')
              if p.is_file() and '__pycache__' not in p.parts
              and p.suffix.lower() in {'.md','.py','.json','.txt'})
assert len(paths)==len(set(paths))
manifest={p.relative_to(ROOT).as_posix():{'bytes':p.stat().st_size,
          'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in paths}
manifest_path=ROOT/'deliverables'/'RESEARCH_MANIFEST.json'
manifest_path.parent.mkdir(exist_ok=True)
manifest_path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf8')
paths.append(manifest_path)
out=ROOT/'deliverables'/'研究记录与验证材料.zip'
with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED) as archive:
    for p in paths: archive.write(p,p.relative_to(ROOT).as_posix())
with zipfile.ZipFile(out) as archive:
    assert archive.testzip() is None
    assert len(archive.namelist())==len(paths)
    for name,item in manifest.items():
        data=archive.read(name)
        assert len(data)==item['bytes']
        assert hashlib.sha256(data).hexdigest()==item['sha256']
print(json.dumps({'files':len(paths),'zip_bytes':out.stat().st_size,
                  'manifest_files_verified':len(manifest),'checks_passed':True},ensure_ascii=False))
