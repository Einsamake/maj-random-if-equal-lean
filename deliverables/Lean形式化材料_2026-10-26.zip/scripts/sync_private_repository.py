"""Refresh the reviewed private GitHub snapshot; does not commit or push."""
from pathlib import Path
import hashlib,json,re,subprocess,posixpath,sys
ROOT=Path(__file__).resolve().parents[1]
TARGET=ROOT/'repository/maj-random-if-equal-lean'
assert TARGET.resolve().is_relative_to(ROOT.resolve())
assert subprocess.check_output(['git','status','--porcelain'],cwd=TARGET,text=True)=='' or sys.argv[1:]==['--resume'], 'Use --resume only to finish a previously prepared managed snapshot'
manifest=json.loads((TARGET/'SNAPSHOT_MANIFEST.json').read_text(encoding='utf8'))
selected={Path(x) for x in manifest['files'] if x not in {'.gitignore','.gitattributes','README.md','docs/VERIFICATION.md'}}
count=0
for kind,base,mod in [('core',Path('formal'),'MathResearch'),('analysis',Path('formal/analysis'),'MathResearchAnalysis')]:
 rec=json.loads((ROOT/'formal/audit'/f'{kind}-validation.json').read_text(encoding='utf8'))
 actual={p.relative_to(ROOT/base).as_posix() for p in (ROOT/base/mod).glob('*.lean')}|{mod+'.lean'}
 assert actual==set(rec['source_sha256'])
 for name,h in rec['source_sha256'].items():
  rel=base/name;assert hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()==h;selected.add(rel);count+=1
for pattern in ['orthogonal-box-stage-*','orthogonal-perimeter-*','orthogonal-physical-box-*', 'orthogonal-boundary-*', 'orthogonal-physical-contour-*', 'protected-geometric-good-*', 'stopped-clock-*', 'droplet-stopped-*', 'clock-word-consistency-*', 'unrevealed-mark-*', 'stopped-mark-slices-*', 'stopped-fresh-mark-*', 'marked-residual-pair-*', 'clock-arrival-count-tail-*', 'marked-ring-count-*', 'marked-ring-integrability-*', 'truncated-exponential-*', 'clock-gap-occupation-*', 'clock-ring-mean-*', 'marked-ring-mean-*', 'clock-interval-history-*', 'clock-interval-count-*', 'marked-interval-factor-*', 'marked-conditional-count-*', 'conditional-clock-*', 'marked-clock-point-measure-*', 'marked-point-measure-*', 'marked-predictable-rectangles-*', 'predictable-clock-reference-*', 'predictable-clock-sigma-*', 'marked-predictable-compensation-*', 'predictable-compensation-*', 'observed-pre-state-*', 'strict-clock-prefix-*', 'actual-pre-state-*', 'predictable-area-contribution-*', 'actual-area-telescope-*', 'real-predictable-compensation-*', 'marked-area-sum-*', 'actual-area-dynkin-*', 'physical-area-generator-*', 'physical-area-tail-*', 'forbidden-birth-*', 'weighted-area-*', 'weighted-exit-*', 'weighted-raw-*', 'physical-weighted-*', 'sync-lower-*', 'mixed-square-*', 'young-*', 'exclusion-*', 'finite-machine-*', 'mixed-moments-*', 'mixed-heat-*', 'mixed-clock-restriction-*', 'cross-square-*', 'sync-upper-*', 'original-sync-upper-*', 'original-theta-*', 'cumulative-cleanup-*', 'clock-time-illustration-*', 'future-gap-history-*', 'marked-clock-filtration-*', 'marked-history-words-*', 'observed-stopping-*', 'observed-frozen-*', 'observed-progressive-*', 'masked-area-generator-*', 'marked-deterministic-residual-*', 'marked-residual-stage-*', 'local-history-exit-*', 'protected-probability-*', 'protected-area-potential-*', 'protected-exit-residual-*', 'frozen-physical-exit-*']:
 selected.update(p.relative_to(ROOT) for p in (ROOT/'formal/audit').glob(pattern) if p.is_file())
for name in ['OrthogonalPerimeter','OrthogonalPhysicalBox']:
 selected.add(Path('formal/drafts')/(name+'.lean'))
selected.add(Path('formal/PROGRESS_2026-10-18_ORTHOGONAL_BOX.md'))
selected.add(Path('docs/PROOF_GUIDE.md'))
selected.add(Path('STATUS.md'))
selected.add(Path('docs/render_explainer.py'))
selected.add(Path('docs/render_clock_timeline.py'))
selected.add(Path('docs/render_particle_encoding.py'))
selected.add(Path('docs/render_mixed_clearing.py'))
# Preserve the reproducible frozen evidence used by independent binding scripts.
selected.update(p.relative_to(ROOT) for p in (ROOT/'formal/audit/history').rglob('*')
 if p.is_file() and p.suffix in {'.md','.json','.log','.lean','.py'}
 and not any(t in p.name.lower() for t in ['wake-','automation','checkpoint']))
for name in ['FiniteSlotPoincare','MixedMomentPoincare','ScalarHeatDecay','CountLowerTail','MixedHeatDecay','MixedRightCountMoments','MixedRightCountHeat','MixedLocalClearing','MixedClearingProbability','ClockSampleRestriction','ClockWordRestriction','SquareInclusion','ClockRestrictedExecution','ClockEndpointSurvival','CrossSquareClockBound','SyncUpperScale','OriginalQuadraticUpper','OriginalQuadraticRecovery']:
 selected.add(Path('formal/drafts')/(name+'.lean'))

selected.update(p.relative_to(ROOT) for p in (ROOT/'docs/images').iterdir() if p.is_file())
for name in ['formal/FORMALIZATION_MAP.md','formal/LEAN_README.md','formal/PROGRESS_2026-10-19_GENERAL_CONTOUR.md','formal/PROGRESS_2026-10-19_STOPPED_CLOCK.md','formal/PROGRESS_2026-10-19_TIME_CONSISTENCY.md','formal/PROGRESS_2026-10-19_PHYSICAL_EXIT.md','research/followup/METHOD_LEDGER_2026-10-19.md','formal/drafts/GridRegionConnectivity.lean','formal/drafts/OrthogonalBoundaryConnectivity.lean','formal/drafts/DropletStoppedWord.lean']:
 selected.add(Path(name))
selected.update(p.relative_to(ROOT) for p in (ROOT/'formal/scripts').glob('*.py'))
selected.update(p.relative_to(ROOT) for p in (ROOT/'research/followup').glob('METHOD_LEDGER_2026-10-2*.md'))
excluded={'HANDOFF.md','formal/CHECKPOINT.md','formal/NEXT_PHASE.md','formal/NEXT_STOPPED_WAIT.md'}
excluded.update(p.relative_to(ROOT).as_posix() for pattern in ['wake-*','automation-*'] for p in (ROOT/'formal/audit').glob(pattern) if p.is_file())
selected.difference_update(Path(n) for n in excluded)
for name in excluded:
 q=TARGET/name
 assert q.resolve().is_relative_to(TARGET.resolve())
 if q.is_file():q.unlink()
selected.update(p.relative_to(ROOT) for p in (ROOT/'formal').glob('*.md') if p.relative_to(ROOT).as_posix() not in excluded)

# Include the local text evidence actually referenced by reviewed documents.
forbidden_parts={'.git','.lake','.tools','archive','repository','quota-resume','.codex','.aws'}
while True:
 additions=set()
 for rel in selected:
  if rel.suffix!='.md':continue
  for link in re.findall(r'\]\(([^)]+)\)',(ROOT/rel).read_text(encoding='utf-8-sig')):
   link=link.strip('<>').split('#')[0]
   if not link or '://' in link or re.match(r'^[A-Za-z]:',link):continue
   q=(ROOT/rel.parent/link).resolve()
   if not q.is_relative_to(ROOT) or not q.is_file():continue
   qr=q.relative_to(ROOT)
   if qr.as_posix() in excluded or set(qr.parts)&forbidden_parts:continue
   if qr.suffix in {'.md','.json','.lean','.py','.toml','.log'}:additions.add(qr)
 additions-=selected
 if not additions:break
 selected.update(additions)

def clean(s):
 for old in ['D:\\\\MyWorks\\\\Math','D:\\MyWorks\\Math','D:/MyWorks/Math','C:\\\\Users\\\\Lenovo\\\\Desktop\\\\Project\\\\Math','C:\\Users\\Lenovo\\Desktop\\Project\\Math']:
  s=s.replace(old,'<workspace>')
 return s.replace('01a13436-cd9d-7d33-892a-db9b997dc601','<local-session>')
for rel in sorted(selected):
 assert not set(rel.parts)&{'.git','.lake','.tools','archive','repository'}
 raw=(ROOT/rel).read_bytes()
 if rel.suffix in {'.md','.json','.log'}:
  s=clean(raw.decode('utf-8-sig'))
  if rel.suffix=='.md':
   def fix(m):
    raw_link=m.group(1).strip()
    if raw_link.startswith('<workspace>/'):
     project_link=re.sub(r':\d+$', '', raw_link[len('<workspace>/'):].split('#')[0])
     candidate=(ROOT/project_link).resolve()
     if candidate.is_relative_to(ROOT) and candidate.is_file() and Path(project_link) in selected:
      return ']('+posixpath.relpath(project_link,rel.parent.as_posix())+')'
     return ']('+posixpath.relpath('README.md',rel.parent.as_posix())+')'
    link=m.group(1).strip('<>').split('#')[0]
    if not link or '://' in link:return m.group(0)
    if re.match(r'^[A-Za-z]:',link):return ']('+posixpath.relpath('README.md',rel.parent.as_posix())+')'
    q=(ROOT/rel.parent/link).resolve()
    if 'history' in rel.parts and not q.exists():
     # Archived Markdown kept its original relative links; repair only the curated copy.
     for parent in [ROOT/'formal/audit',ROOT/'formal',ROOT]:
      candidate=(parent/link).resolve()
      if candidate.is_relative_to(ROOT) and candidate.is_file() and candidate.relative_to(ROOT) in selected:
       return ']('+posixpath.relpath(candidate.relative_to(ROOT).as_posix(),rel.parent.as_posix())+')'
     return ']('+posixpath.relpath('README.md',rel.parent.as_posix())+')'
    if q.is_relative_to(ROOT) and (q.relative_to(ROOT).as_posix() in excluded or set(q.relative_to(ROOT).parts)&forbidden_parts):
     return ']('+posixpath.relpath('README.md',rel.parent.as_posix())+')'
    return m.group(0)
   s=re.sub(r'\]\(([^)]+)\)',fix,s)
  raw=s.encode('utf8')
 out=TARGET/rel;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(raw)
rec=json.loads((ROOT/'formal/audit/analysis-validation.json').read_text(encoding='utf8'))
# Keep the reader-facing introduction authored in the workspace; do not regenerate jargon.
readme=(ROOT/'README.md').read_text(encoding='utf8')
(TARGET/'README.md').write_text(readme,encoding='utf8')
verification=(ROOT/'docs/VERIFICATION.md').read_text(encoding='utf8')
(TARGET/'docs/VERIFICATION.md').write_text(verification,encoding='utf8')
links=0;files={}
for p in sorted(TARGET.rglob('*')):
 if not p.is_file() or '.git' in p.parts or p.name=='SNAPSHOT_MANIFEST.json':continue
 rel=p.relative_to(TARGET).as_posix();raw=p.read_bytes()
 if p.suffix.lower() in {'.png','.gif'}:
  files[rel]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
  continue
 s=raw.decode('utf8')
 assert not re.search(r'(?:gh[pousr]_[A-Za-z0-9_]{25,}|sk-[A-Za-z0-9_-]{24,}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----)',s),rel
 if p.suffix=='.md':
  for link in re.findall(r'\]\(([^)]+)\)',s):
   link=link.strip('<>').split('#')[0]
   if not link or '://' in link:continue
   q=(p.parent/link).resolve();assert q.is_relative_to(TARGET) and q.exists(),(rel,link);links+=1
 files[rel]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
for kind,base in [('core',Path('formal')),('analysis',Path('formal/analysis'))]:
 rec=json.loads((TARGET/'formal/audit'/f'{kind}-validation.json').read_text(encoding='utf8'))
 for name,sha in rec['source_sha256'].items():assert files[(base/name).as_posix()]['sha256']==sha
for name, item in files.items():
 origin=ROOT/name
 if origin.is_file():
  item['workspace_sha256']=hashlib.sha256(origin.read_bytes()).hexdigest()
  item['byte_identical_to_workspace']=item['workspace_sha256']==item['sha256']
(TARGET/'SNAPSHOT_MANIFEST.json').write_text(json.dumps({'formal_sources_verified':count,'metadata_note':'Formal Lean bytes are exact; Markdown, JSON and log local paths may be sanitized. workspace_sha256 binds original local evidence; sha256 binds this curated snapshot. Raw local evidence hashes may differ from sanitized-log hashes.','files':files},ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({'formal_sources_verified':count,'files':len(files)+1,'local_links_checked':links,'possible_credentials_found':False}))
