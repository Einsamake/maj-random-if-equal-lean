"""Check the reviewed workspace reorganization without rebuilding unchanged proofs."""
from pathlib import Path
from datetime import datetime, timezone, timedelta
import ast
import hashlib
import json
import re
from urllib.parse import unquote

ROOT = Path(__file__).resolve().parents[1]
record_path = ROOT / 'archive' / 'organization-2026-10-14.json'
record = json.loads(record_path.read_text(encoding='utf-8-sig'))
record['deleted_bytes'] = sum(item['bytes'] for item in record['deleted'])
record_path.write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf8')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


edited_scripts = {'scripts/build_report.py', 'scripts/package_materials.py', 'scripts/export_word.ps1'}
for item in record['moved'] + record['copied']:
    target = ROOT / item['to']
    assert target.is_file(), item['to']
    if item['to'] not in edited_scripts:
        assert digest(target) == item['sha256'], item['to']
for item in record['deleted']:
    assert not (ROOT / item['path']).exists(), item['path']

checked_sources = 0
for name, base in [('core', ROOT / 'formal'), ('analysis', ROOT / 'formal' / 'analysis')]:
    validation = json.loads((ROOT / 'formal' / 'audit' / f'{name}-validation.json').read_text(encoding='utf8'))
    assert validation['build_exit'] == validation['axiom_audit_exit'] == 0
    module_dir = 'MathResearch' if name == 'core' else 'MathResearchAnalysis'
    actual_sources = set((base / module_dir).glob('*.lean')) | {base / f'{module_dir}.lean'}
    validated_sources = {base / source for source in validation['source_sha256']}
    assert actual_sources == validated_sources, 'Project source set changed: run the full validator first'
    for source, expected in validation['source_sha256'].items():
        assert digest(base / source) == expected, source
        checked_sources += 1

for directory in (ROOT / 'scripts', ROOT / 'formal' / 'scripts'):
    for script in directory.glob('*.py'):
        ast.parse(script.read_text(encoding='utf8'), filename=str(script))

documents = ['docs/images/README.md', 'docs/PROOF_GUIDE.md', 'docs/VERIFICATION.md', '工作区整理与工具研究_2026-10-16.md', 'README.md', 'HANDOFF.md', 'STATUS.md', '阶段性成果_2026-10-14.md',
             '复盘与后续路线_2026-10-14.md', 'reports/initial-research/README.md',
             'formal/FORMALIZATION_MAP.md', 'formal/LEAN_README.md',
             'formal/NEXT_PHASE.md', 'formal/NEXT_STOPPED_WAIT.md',
             'formal/FINITE_PW_CONTRACT.md', 'formal/PROGRESS_2026-10-14_PW.md',
             'formal/PROGRESS_2026-10-14_COMPARISON.md',
             'formal/PROGRESS_2026-10-14_RANDOM_RECOVERY.md',
             'formal/PROGRESS_2026-10-15_GRID.md', 'deliverables/README.md',
             'formal/PROGRESS_2026-10-15_ORIGINAL_STATEMENT.md',
             'formal/CMST_DEPENDENCY_PLAN.md',
             'formal/audit/original-statement-semantic-review.md',
             'formal/PROGRESS_2026-10-15_MAJORITY_PEELING.md',
             'formal/PROGRESS_2026-10-16_CLIPPED_DROPLET.md',
             'formal/PROGRESS_2026-10-16_MODIFIED_CLOCK.md',
             'formal/PROGRESS_2026-10-16_PROTECTED_DOMAIN.md',
             'formal/PROGRESS_2026-10-17_CONTOUR_FOUNDATION.md',
             'formal/PROGRESS_2026-10-17_GEOMETRIC_CONTOUR.md', 'formal/PROGRESS_2026-10-17_LOCAL_UPDATE.md', 'formal/PROGRESS_2026-10-18_PROTECTED_EVOLUTION.md', 'formal/PROGRESS_2026-10-18_ORTHOGONAL_BOX.md', 'research/followup/METHOD_LEDGER_2026-10-18.md',
             'formal/audit/contour-foundation-semantic-review.md',
             'formal/audit/protected-domain-semantic-review.md', 'formal/CHECKPOINT.md',
             'formal/audit/modified-clock-semantic-review.md',
             'formal/audit/clipped-droplet-semantic-review.md',
             'formal/audit/majority-peeling-semantic-review.md',
             'formal/INFINITE_GRID_CONTRACT.md', 'formal/ORIGINAL_STATEMENT_CONTRACT.md',
             'research/followup/PROGRESS_ESTIMATE_2026-10-14.md',
             '形式化独立核查_2026-10-14.md']
stage_audit_patterns = (
    'stopped-clock-*', 'droplet-stopped-*', 'unrevealed-mark-*', 'stopped-mark-slices-*', 'stopped-fresh-mark-*', 'marked-residual-pair-*', 'clock-arrival-count-tail-*', 'marked-ring-count-*', 'marked-ring-integrability-*', 'truncated-exponential-*', 'clock-gap-occupation-*', 'clock-ring-mean-*', 'marked-ring-mean-*', 'clock-interval-history-*', 'clock-interval-count-*', 'marked-interval-factor-*', 'marked-conditional-count-*', 'conditional-clock-*', 'marked-clock-point-measure-*', 'marked-point-measure-*', 'marked-predictable-rectangles-*', 'predictable-clock-reference-*', 'predictable-clock-sigma-*', 'marked-predictable-compensation-*', 'predictable-compensation-*', 'observed-pre-state-*', 'strict-clock-prefix-*', 'actual-pre-state-*', 'predictable-area-contribution-*', 'actual-area-telescope-*', 'real-predictable-compensation-*', 'marked-area-sum-*', 'actual-area-dynkin-*', 'physical-area-generator-*', 'physical-area-tail-*', 'forbidden-birth-*', 'weighted-area-*', 'weighted-exit-*', 'weighted-raw-*', 'physical-weighted-*', 'sync-lower-*', 'mixed-square-*', 'young-*', 'exclusion-*', 'finite-machine-*', 'mixed-moments-*', 'mixed-heat-*', 'mixed-clock-restriction-*', 'cross-square-*', 'sync-upper-*', 'original-sync-upper-*', 'original-theta-*', 'cumulative-cleanup-*', 'clock-time-illustration-*', 'future-gap-history-*', 'marked-clock-filtration-*', 'marked-history-words-*', 'observed-stopping-*', 'observed-frozen-*', 'observed-progressive-*', 'masked-area-generator-*', 'marked-deterministic-residual-*', 'marked-residual-stage-*', 'local-history-exit-*', 'protected-probability-*', 'protected-area-potential-*', 'protected-exit-residual-*', 'frozen-physical-exit-*', 'clock-word-consistency-*', 'orthogonal-boundary-*', 'orthogonal-physical-contour-*', 'protected-geometric-good-*', 'region-*', 'update-stage-*', 'protected-column-*', 'protected-corner-*', 'protected-stage-*', 'exit-area-stage-*', 'vacant-quadrant-*', 'orthogonal-perimeter-*', 'orthogonal-physical-box-*', 'orthogonal-box-stage-*', 'grid-region-connectivity-*', 'github-private-repository.json', 'github-snapshot-validation.json', 'convex-birth-update-*', 'grid-perimeter-update-*', 'grid-perimeter-dynamics-*', 'cleanup-connectivity-*', 'grid-cell-region-*', 'grid-physical-region-*', 'grid-contour-length-*',
    'clipped-boundary-*', 'clipped-region-box-*', 'clipped-physical-box-*',
    'clipped-initial-contour-*', 'geometric-contour-*', 'wake-0505-*',
)
stage_audits = sorted({
    path for pattern in stage_audit_patterns
    for path in (ROOT / 'formal' / 'audit').glob(pattern) if path.is_file()
})
documents += [path.relative_to(ROOT).as_posix()
              for path in stage_audits if path.suffix == '.md']
documents += ['formal/PROGRESS_2026-10-19_PHYSICAL_EXIT.md', 'formal/PROGRESS_2026-10-19_TIME_CONSISTENCY.md', 'formal/PROGRESS_2026-10-19_STOPPED_CLOCK.md', 'formal/PROGRESS_2026-10-19_GENERAL_CONTOUR.md', 'research/followup/METHOD_LEDGER_2026-10-19.md']
documents += [p.relative_to(ROOT).as_posix() for p in (ROOT/'formal').glob('PROGRESS_2026-10-2*.md')]
documents += ['research/followup/METHOD_LEDGER_2026-10-20.md','research/followup/METHOD_LEDGER_2026-10-21.md']
documents += ['research/followup/METHOD_LEDGER_2026-10-23.md', 'research/followup/METHOD_LEDGER_2026-10-24.md', 'research/followup/METHOD_LEDGER_2026-10-25.md', 'research/followup/METHOD_LEDGER_2026-10-26.md', 'research/followup/METHOD_LEDGER_2026-10-26_MOMENTS.md', 'research/followup/METHOD_LEDGER_2026-10-26_FINAL.md', 'research/followup/NEXT_SYNC_LOWER_ROUTE_2026-10-25.md']
documents = list(dict.fromkeys(documents))
stage_json_records = 0
for path in stage_audits:
    if path.suffix == '.json':
        json.loads(path.read_text(encoding='utf-8-sig'))
        stage_json_records += 1

checked_links = 0
for name in documents:
    document = ROOT / name
    for target in re.findall(r'\]\(([^)]+)\)', document.read_text(encoding='utf8')):
        if re.match(r'^[A-Za-z]+://', target) or target.startswith('#'):
            continue
        target_path = re.sub(r':\d+$', '', unquote(target.split('#', 1)[0].strip('<>')))
        path = (document.parent / target_path).resolve()
        assert path.is_relative_to(ROOT) and path.exists(), (name, target)
        checked_links += 1

summary = {
    'validated_at': datetime.now(timezone(timedelta(hours=8))).isoformat(),
    'moved_files_verified': len(record['moved']),
    'historical_snapshots_verified': len(record['copied']),
    'historical_deleted_files_verified_absent': len(record['deleted']),
    'historical_deleted_bytes': record['deleted_bytes'],
    'formal_source_hashes_matched': checked_sources,
    'current_document_links_checked': checked_links,
    'stage_audit_files_found': len(stage_audits),
    'stage_audit_json_records_parsed': stage_json_records,
    'python_scripts_parse': True,
    'proof_build_rerun_by_this_script': False,
    'scope': 'read back historical organization, existing audit/source consistency and links; no file deletions performed; not a new proof',
    'checks_passed': True,
}
output = ROOT / 'formal' / 'audit' / 'workspace-validation.json'
output.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
print(json.dumps(summary, ensure_ascii=False))

