"""Build the editable Chinese report using bundled python-docx."""
from pathlib import Path
import re
from docx import Document
from docx.shared import Cm, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.opc.constants import RELATIONSHIP_TYPE

ROOT=Path(__file__).resolve().parents[1]
REPORTS=ROOT/'reports'/'initial-research'

def font(run,size=None,math=False):
    run.font.name='Cambria Math' if math else 'Calibri'
    if size: run.font.size=Pt(size)
    run.font.color.rgb=RGBColor(0,0,0)
    run._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'),'宋体')

def hyperlink(paragraph,label,url):
    link=OxmlElement('w:hyperlink')
    link.set(qn('r:id'),paragraph.part.relate_to(url,RELATIONSHIP_TYPE.HYPERLINK,is_external=True))
    r=OxmlElement('w:r'); props=OxmlElement('w:rPr')
    color=OxmlElement('w:color'); color.set(qn('w:val'),'1F4E79'); props.append(color)
    fonts=OxmlElement('w:rFonts'); fonts.set(qn('w:ascii'),'Calibri'); fonts.set(qn('w:hAnsi'),'Calibri'); fonts.set(qn('w:eastAsia'),'宋体'); props.append(fonts)
    r.append(props); text=OxmlElement('w:t'); text.text=label; r.append(text); link.append(r); paragraph._p.append(link)

def inline(paragraph,text,math=False):
    pattern=re.compile(r'(\[[^\]]+\]\(https?://[^)]+\)|\*\*[^*]+\*\*|https?://\S+)')
    pos=0
    for match in pattern.finditer(text):
        if match.start()>pos: font(paragraph.add_run(text[pos:match.start()]),math=math)
        token=match.group()
        if token.startswith('['):
            m=re.match(r'\[([^\]]+)\]\(([^)]+)\)',token); hyperlink(paragraph,m[1],m[2])
        elif token.startswith('**'):
            r=paragraph.add_run(token[2:-2]); font(r,math=math); r.bold=True
        else: hyperlink(paragraph,token,token)
        pos=match.end()
    if pos<len(text): font(paragraph.add_run(text[pos:]),math=math)

def table(doc,rows):
    rows=[[s.strip() for s in r.strip().strip('|').split('|')] for r in rows]
    rows=[r for r in rows if not all(re.fullmatch(r'[:\- ]+',s) for s in r)]
    cols=len(rows[0]); t=doc.add_table(rows=0,cols=cols); t.alignment=WD_TABLE_ALIGNMENT.CENTER; t.autofit=False
    widths=[4,5.8,6.7] if '内容'==rows[0][0] else [3,6.75,6.75]
    for k,data in enumerate(rows):
        cells=t.add_row().cells
        for j,cell in enumerate(cells):
            cell.width=Cm(widths[j]); cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
            props=cell._tc.get_or_add_tcPr()
            borders=OxmlElement('w:tcBorders')
            for side in ['top','left','bottom','right']:
                edge=OxmlElement('w:'+side); edge.set(qn('w:val'),'single'); edge.set(qn('w:sz'),'4'); edge.set(qn('w:color'),'D9D9D9'); borders.append(edge)
            props.append(borders)
            shade=OxmlElement('w:shd'); shade.set(qn('w:fill'),'DCE6F1' if k==0 else ('F3F5F7' if k%2==0 else 'FFFFFF')); props.append(shade)
            margins=OxmlElement('w:tcMar')
            for name,value in [('top',80),('bottom',80),('left',110),('right',110)]:
                e=OxmlElement('w:'+name); e.set(qn('w:w'),str(value)); e.set(qn('w:type'),'dxa'); margins.append(e)
            props.append(margins)
            p=cell.paragraphs[0]; p.paragraph_format.space_after=Pt(0); p.paragraph_format.line_spacing=1.15
            p.alignment=WD_ALIGN_PARAGRAPH.LEFT if rows[0][0]=='内容' else WD_ALIGN_PARAGRAPH.CENTER
            inline(p,data[j]);
            for run in p.runs: font(run,9.5); run.bold=(k==0)
        if k==0:
            repeat=OxmlElement('w:tblHeader'); cells[0]._tc.getparent().get_or_add_trPr().append(repeat)
        prevent=OxmlElement('w:cantSplit'); cells[0]._tc.getparent().get_or_add_trPr().append(prevent)
    doc.add_paragraph().paragraph_format.space_after=Pt(0)

def main():
    doc=Document(); sec=doc.sections[0]; sec.page_width=Cm(21); sec.page_height=Cm(29.7)
    sec.top_margin=sec.bottom_margin=Cm(2); sec.left_margin=sec.right_margin=Cm(2.1)
    for name in ['Normal','Title','Heading 1','Heading 2']:
        style=doc.styles[name]; style.font.name='Calibri'; style.font.color.rgb=RGBColor(0,0,0)
        style._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'),'宋体')
    normal=doc.styles['Normal']; normal.font.size=Pt(10.5); normal.paragraph_format.line_spacing=1.25; normal.paragraph_format.space_after=Pt(6)
    doc.styles['Title'].font.size=Pt(20); doc.styles['Title'].paragraph_format.space_after=Pt(12)
    doc.styles['Heading 1'].font.size=Pt(14); doc.styles['Heading 1'].paragraph_format.space_before=Pt(12); doc.styles['Heading 1'].paragraph_format.space_after=Pt(6)
    doc.styles['Heading 2'].font.size=Pt(12)
    # Remove the default Word Title style's blue border.
    for border in list(doc.styles.element.xpath('.//w:pBdr')):
        border.getparent().remove(border)
    lines=(REPORTS/'REPORT.md').read_text(encoding='utf8').splitlines(); i=0
    while i<len(lines):
        line=lines[i]; i+=1
        if not line.strip(): continue
        if line.startswith('|'):
            rows=[line]
            while i<len(lines) and lines[i].startswith('|'): rows.append(lines[i]); i+=1
            table(doc,rows); continue
        if line.startswith('# '): p=doc.add_paragraph(style='Title'); inline(p,line[2:]); continue
        if line.startswith('## '):
            p=doc.add_paragraph(style='Heading 1')
            inline(p,line[3:]); continue
        if line.startswith('### '): p=doc.add_paragraph(style='Heading 2'); inline(p,line[4:]); continue
        p=doc.add_paragraph(); inline(p,line.strip(),math=line.startswith('    '))
        if line.startswith('    '):
            p.paragraph_format.left_indent=Cm(.25); p.paragraph_format.space_before=Pt(3); p.paragraph_format.space_after=Pt(7)
            for run in p.runs: font(run,10.5,True)
    p=sec.footer.paragraphs[0]; p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    field=OxmlElement('w:fldSimple'); field.set(qn('w:instr'),'PAGE'); p._p.append(field)
    doc.core_properties.title='数学开放问题证明尝试记录'; doc.core_properties.subject='数据挑选回归与随机多数细胞自动机'; doc.core_properties.author='AI 辅助研究记录'
    out=REPORTS/'数学开放问题证明尝试记录.docx'; doc.save(out); print(out)
    parts=[('细胞自动机整洁候选证明','research/followup/ca_clean_proof.md'),('回归原问题与精确复现','research/online/selected_problem.md'),('回归部分上界完整推导','research/predictive_coding/proof_attempt.md'),('03:20续做：细胞自动机独立审查','research/followup/ca_fresh_audit.md'),('03:20续做：回归独立审查与完整三角形路线','research/followup/regression_fresh_review.md'),('03:20续做：一手文献及新颖性审查','research/followup/novelty_review.md'),('回归部分上界首轮独立审查','research/online/covariance_bound_audit.md'),('七边形精确证书','research/online/heptagon_certificate.md'),('细胞自动机历史推导与较弱路线','research/cellular/quadratic_upper_draft.md'),('细胞自动机上界及初步下界首轮独立审查','research/predictive_coding/ca_independent_review.md'),('细胞自动机平方下界首轮独立审查','research/predictive_coding/ca_readiness_review.md'),('细胞自动机平方下界首轮第三次审查','research/online/ca_lower_audit.md')]
    appendix=['# 数学证明尝试技术附录','本附录保留两轮推导和审查。当前结论与新颖性边界以 REPORT.md 和 STATUS.md 为准。建议先读前面的整洁CA证明或回归完整推导，再看03:20续做的三个审查；末尾保留历史试错稿，其阶段性结论并非当前状态。','']
    for title,path in parts:
        if (ROOT/path).exists(): appendix.extend(['---',f'# {title}','', (ROOT/path).read_text(encoding='utf8'),''])
    (REPORTS/'TECHNICAL_APPENDIX.md').write_text('\n'.join(appendix),encoding='utf8')

if __name__=='__main__': main()
