$ErrorActionPreference = 'Stop'
$workspaceRoot = Split-Path -Parent $PSScriptRoot
$researchDocument = Join-Path $workspaceRoot 'reports\initial-research\数学开放问题证明尝试记录.docx'
$researchPdf = Join-Path $workspaceRoot 'reports\initial-research\qa\report.pdf'
New-Item -ItemType Directory -Path (Split-Path -Parent $researchPdf) -Force | Out-Null
$researchWord = $null
$researchOpenedDocument = $null
try {
    $researchWord = New-Object -ComObject Word.Application
    $researchWord.Visible = $false
    $researchWord.DisplayAlerts = 0
    $researchOpenedDocument = $researchWord.Documents.Open($researchDocument, $false, $true)
    $researchOpenedDocument.ExportAsFixedFormat($researchPdf, 17)
    Write-Output $researchPdf
} finally {
    if ($null -ne $researchOpenedDocument) { $researchOpenedDocument.Close(0) }
    if ($null -ne $researchWord) { $researchWord.Quit() }
}
